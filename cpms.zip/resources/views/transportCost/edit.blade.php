@extends('layouts.app')

@section('content')
    <div class="container">
        <!-- card components -->
        <div class="row">
            <!-- card single -->
            <div class="col-lg-12 mb-3">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5>Transport Cost Update</h5>

                        <div class="btn-group" role="group" aria-label="Action area">
                            <a href="{{ route('transportCost.index') }}" class="btn btn-primary" title="All equipment purchase.">
                                <i class="fa fa-list"></i>
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('transportCost.update', $transport_cost->id) }}" method="POST">
                            @csrf
                            @method('PATCH')
                            <div class="mb-2">
                                <span style="font-size: small">(NB: All <span style="color: red">*</span> mark must fillable)</span>
                            </div>
                            @if(count($user_sites) > 1)
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="site_id" class="required">Select Site</label>
                                        <select class="form-control" name="site_id" id="site_id">
                                            <option value="">Choose One</option>
                                            @foreach($user_sites as $site)
                                                <option {{ ($site->id == $transport_cost->site_id) ? 'selected' : '' }} value="{{ $site->id }}">{{ $site->title }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            @else
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="site_id" class="required">Site Name</label>
                                        @foreach($user_sites as $site)
                                            <input type="text" class="form-control" value="{{ $site->title }}" readonly>
                                            <input type="hidden" name="site_id" class="form-control" value="{{ $site->id }}">
                                        @endforeach
                                    </div>
                                </div>
                            @endif

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="transport_name" class="required">Transport Name</label>
                                    <input type="text" class="form-control" value="{{ $transport_cost->transport_name }}" required placeholder="enter transport name" name="transport_name" id="transport_name">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="date" class="required">Date</label>
                                    <input type="date" class="form-control" value="{{ $transport_cost->date->format('Y-m-d') }}" name="date" id="date">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="purpose">Purpose</label>
                                    <input type="text" class="form-control" value="{{ $transport_cost->purpose }}" placeholder="enter purpose" name="purpose" id="purpose">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="amount" class="required">Amount</label>
                                    <input type="number" class="form-control" value="{{ number_format($transport_cost->amount, 2) }}" placeholder="enter amount" required name="amount" id="amount">
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary float-right">Save</button>
                            <button type="reset" class="btn btn-danger float-right mr-2">Reset</button>
                        </form>
                    </div>
                </div>
            </div>
            <!-- card single end -->
        </div>
    </div>
@endsection
