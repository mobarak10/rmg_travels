@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12 py-3">

            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="m-0">Create New Supplier</h5>
                    <div class="btn-group" role="group" aria-label="Action area">
                        <a href="{{ route('supplier.index') }}" class="btn btn-primary" title="All supplier">
                            <i class="fa fa-list" aria-hidden="true"></i>
                        </a>
                    </div>
                </div>

                <div class="card-body p-0">
                    <div class="col-12 py-2">
                        <form action="{{ route('supplier.store') }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <div class="mb-2">
                                <span style="font-size: small">(NB: All <span style="color: red">*</span> mark must fillable)</span>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-12">
                                    <label for="name" class="required">Name</label>
                                    <input type="text" name="name" class="form-control" id="name" required placeholder="Name">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="phone" class="required">Phone</label>
                                    <input type="text" name="phone" class="form-control" required id="phone" placeholder="Phone">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="balance">Balance</label>
                                    <input type="number" name="balance" class="form-control" id="balance" placeholder="Enter supplier balance">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="division">Division</label>
                                    <input class="form-control" name="division" id="division" placeholder="Enter division" />
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="district">District</label>
                                    <input class="form-control" name="district" id="district" placeholder="Enter district" />
                                </div>
                            </div>

{{--                            <div class="form-row">--}}
{{--                                <div class="form-group col-md-6">--}}
{{--                                    <label for="thana">Thana</label>--}}
{{--                                    <input class="form-control" name="thana" id="thana" placeholder="Enter thana" />--}}
{{--                                </div>--}}
{{--                                <div class="form-group col-6">--}}
{{--                                    <label for="logo">@lang('contents.logo_media_id')</label>--}}
{{--                                    <input type="number" name="thumbnail" class="form-control" id="logo" placeholder="Enter Media Code">--}}
{{--                                </div>--}}
{{--                            </div>--}}

                            <div class="text-right">
                                <button type="reset" class="btn btn-danger">Reset</button>
                                <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>
@endsection
