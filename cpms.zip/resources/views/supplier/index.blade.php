@extends('layouts.app')

@section('content')
    <!-- Main Content -->
    <div class="container">

        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="m-0">All Supplier</h5>
                <div class="btn-group" role="group" aria-label="Action area">
                    <a href="{{ route('supplier.create') }}" class="btn btn-primary btn-sm rounded" title="Create new account.">
                        <i class="fa fa-plus"></i>
                    </a>
                </div>
            </div>

            <div class="card-body p-0">
                <table class="table table-bordered table-striped table-sm">
                    <thead>
                    <tr>
                        <th class="text-center">#</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Division</th>
                        <th>District</th>
                        <th class="text-right">Balance</th>
                        <th class="text-right">Action</th>
                    </tr>
                    </thead>

                    <tbody>
                    @foreach($suppliers as $supplier)
                        <tr>
                            <td class="text-center">{{ $loop->index + 1 }}.</td>
                            <td>{{ $supplier->name }}</td>
                            <td>{{ $supplier->phone }}</td>
                            <td>{{ $supplier->division }}</td>
                            <td>{{ $supplier->district }}</td>
                            <td class="text-right">{{ number_format($supplier->balance, 2) }}</td>
                            <td class="text-right">
{{--                                <a href="{{ route('supplier.show', $supplier->id) }}" class="btn btn-success" title="Employee details.">--}}
{{--                                    <i class="fa fa-eye" aria-hidden="true"></i>--}}
{{--                                </a>--}}

                                <a href="{{ route('supplier.edit', $supplier->id) }}" class="btn btn-primary btn-sm" title="Change account information.">
                                    <i class="fa fa-pencil" aria-hidden="true"></i>
                                </a>


                                <a href="{{ route('supplier.index') }}" class="btn btn-danger btn-sm" title="Trash" onClick="if(confirm('Are you sure, You want to delete this?')){event.preventDefault();document.getElementById('delete-form-{{ $supplier->id }}').submit();} else {event.preventDefault();}">
                                    <i class="fa fa-times" aria-hidden="true"></i>
                                </a>

                                <form action="{{ route('supplier.destroy', $supplier->id) }}" method="post" id="delete-form-{{ $supplier->id }}" style="display: none;">
                                    {{ csrf_field() }}
                                    {{ method_field('DELETE') }}
                                </form>

                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection

