@extends('layouts.app')
@section('content')
    <!-- Main Content -->
    <div class="container">

        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="m-0">All Equipment Purchase</h5>

                <div class="btn-group" role="group" aria-label="Action area">
                    <a href="#" onclick="window.print();" title="Print" class="btn btn-secondary btn-sm print-none rounded mr-1"><i aria-hidden="true" class="fa fa-print"></i></a>
                    <!-- for refresh -->
                    <a href="{{ route('equipmentPurchase.index') }}" class="btn btn-warning print-none rounded btn-sm mr-1" title="Refresh">
                        <i class="fa fa-refresh" aria-hidden="true"></i>
                    </a>

                    <button class="btn btn-info btn-sm mr-1 print-none rounded" type="button" data-toggle="collapse" data-target="#searchEquipment">
                        <i class="fa fa-search"></i>
                    </button>

                    <a href="{{ route('equipmentPurchase.create') }}" class="btn btn-primary btn-sm print-none rounded" title="Entry new labour cost.">
                        <i class="fa fa-plus"></i>
                    </a>
                    <p class="text-center d-none d-print-block">Date: {{ date('Y-m-d') }}</p>
                </div>

            </div>

            <div class="card-body p-0">
                <div class="from-row">
                    <div class="collapse align-items-center" id="searchEquipment">
                        <form action="{{ route('equipmentPurchase.index') }}" method="GET">
                            <input type="hidden" name="search" value="1">

                            <div class="row ml-1 m-1">
                                <div class="form-group col-md-4">
                                    <label for="date-from">From Date</label>
                                    <input type="date" class="form-control" name="from_date" value="{{ request()->from_date ?? '' }}" id="date-form">
                                </div>

                                <div class="form-group col-md-4">
                                    <label for="date-to">To Date</label>
                                    <input type="date" class="form-control" name="to_date" value="{{ request()->to_date ?? date('Y-m-d') }}" id="date-to">
                                </div>

                                <div class="form-group col-md-4">
                                    <label for="site_id">Site Name</label>
                                    <select name="condition[site_id]" id="site_id" class="form-control">
                                        <option value="">Choose One</option>
                                        @foreach($user_sites as $site)
                                            <option {{ ((request()->condition['site_id'] ?? '') == $site->id) ? 'selected' : '' }} value="{{ $site->id }}">{{ $site->title }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="supplier_id">Supplier</label>
                                    <select name="condition[supplier_id]" id="supplier_id" class="form-control">
                                        <option value="">Choose One</option>
                                        @foreach($suppliers as $supplier)
                                            <option {{ ((request()->condition['supplier_id'] ?? '') == $supplier->id) ? 'selected' : '' }} value="{{ $supplier->id }}">
                                                {{ $supplier->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group col-md-4">
                                    <label for="item_name">Item Name</label>
                                    <input type="text" class="form-control" name="condition[item_name]" value="{{ request()->condition['item_name'] ?? '' }}" id="item_name">
                                </div>

                                <div class="form-group col-md-2 text-right" style="margin-top: 30px">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-search"></i>
                                        Search
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <table class="table table-sm table-striped table-bordered">
                    <thead>
                    <tr>
                        <th class="text-center">#</th>
                        <th>Site Name</th>
                        <th>Date</th>
                        <th>Purchase Item</th>
                        <th class="text-right">Quantity</th>
                        <th class="text-right">Amount</th>
{{--                        <th>Operator</th>--}}
                        <th class="text-right print-none">Action</th>
                    </tr>
                    </thead>

                    <tbody>
                    @forelse($equipment_purchases as $equipment_purchase)
                        <tr>
                            <td class="text-center">{{ $loop->index + 1 }}.</td>
                            <td>{{ $equipment_purchase->sites->title }}</td>
                            <td>{{ $equipment_purchase->purchase_date->format('d-M-Y') }}</td>
                            <td>{{ $equipment_purchase->item_name }}</td>
                            <td class="text-right">{{ $equipment_purchase->quantity }}</td>
                            <td class="text-right">{{ number_format($equipment_purchase->total_price, 2) }}</td>
                            <td class="text-right print-none">
                                @can('viewAny', App\Models\User::class)
                                    <a href="{{ route('equipmentPurchase.show', $equipment_purchase->id) }}" class="btn btn-success btn-sm" title="Labour cost details.">
                                        <i class="fa fa-eye" aria-hidden="true"></i>
                                    </a>
                                @endcan

                                <a href="{{ route('equipmentPurchase.edit', $equipment_purchase->id) }}" class="btn btn-primary btn-sm" title="Change labour cost information.">
                                    <i class="fa fa-pencil" aria-hidden="true"></i>
                                </a>

                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="text-center">No Equipment purchase available</td>
                        </tr>
                    @endforelse
                    </tbody>
                </table>
                <!-- paginate -->
                <div class="float-right mx-2">{{ $equipment_purchases->links() }}</div>
            </div>
        </div>
    </div>
@endsection

