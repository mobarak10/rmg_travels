@extends('layouts.app')

@section('content')
    <!-- Main Content -->
    <div class="container">
        <div class="row mb-2">
            <div class="col-md-2">

            </div>
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center">
                        Equipment Purchase Information
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush align-items-center">
                            <li class="list-group-item"><span class="font-weight-bold">Site Name:</span> {{ $equipment_purchase->sites->title }}</li>
                            <li class="list-group-item"><span class="font-weight-bold">Purchase By:</span> {{ $equipment_purchase->users->name }}</li>
                            <li class="list-group-item"><span class="font-weight-bold">Supplier:</span> {{ $equipment_purchase->suppliers->name }}</li>
                            <li class="list-group-item"><span class="font-weight-bold">Item Name:</span> {{ $equipment_purchase->item_name }}</li>
                            <li class="list-group-item"><span class="font-weight-bold">Unit Price:</span> {{ number_format($equipment_purchase->unit_price, 2) }}</li>
                            <li class="list-group-item"><span class="font-weight-bold">Quantity:</span> {{ $equipment_purchase->quantity }}</li>
                            <li class="list-group-item"><span class="font-weight-bold">Total Item Price:</span> {{ number_format($equipment_purchase->total_price, 2) }}</li>
                            <li class="list-group-item"><span class="font-weight-bold">Labour Cost:</span> {{ number_format($equipment_purchase->labour_cost, 2) }}</li>
                            <li class="list-group-item"><span class="font-weight-bold">Transport Cost:</span> {{ number_format($equipment_purchase->transport_cost, 2) }}</li>
                            <li class="list-group-item"><span class="font-weight-bold">Total Cost:</span> {{ number_format($equipment_purchase->transport_cost+$equipment_purchase->labour_cost+$equipment_purchase->total_price, 2) }}</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-2">

            </div>
        </div>

        <!--Section: Block Content-->
    </div>
@endsection

