@extends('layouts.app')

@section('content')
    <div class="container">
        <!-- card components -->
        <div class="row">
            <!-- card single -->
            <div class="col-lg-12 mb-3">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5>Equipment Purchase Update</h5>

                        <div class="btn-group" role="group" aria-label="Action area">
                            <a href="{{ route('equipmentPurchase.index') }}" class="btn btn-primary" title="All equipment purchase.">
                                <i class="fa fa-list"></i>
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('equipmentPurchase.update', $equipment_purchase->id) }}" method="POST">
                            @csrf
                            @method('PATCH')
                            <div class="mb-2">
                                <span style="font-size: small">(NB: All <span style="color: red">*</span> mark must fillable)</span>
                            </div>
                            @if(count($user_sites->sites) > 1)
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="site_id" class="required">Select Site</label>
                                        <select class="form-control" name="site_id" id="site_id">
                                            <option value="">Choose One</option>
                                            @foreach($user_sites->sites as $site)
                                                <option value="{{ $site->id }}" {{ ($equipment_purchase->sites->id == $site->id) ? 'selected' : '' }}>{{ $site->title }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            @endif

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="item_name" class="required">Equipment Name</label>
                                    <input type="text" class="form-control" value="{{ $equipment_purchase->item_name }}" placeholder="enter equipment name" required name="item_name" id="item_name" aria-describedby="emailHelp">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="unit_price">Unit Price</label>
                                    <input type="text" class="form-control" value="{{ $equipment_purchase->unit_price }}" placeholder="enter unit price" name="unit_price" id="unit_price" aria-describedby="emailHelp">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="quantity" class="required">Quantity</label>
                                    <input type="text" class="form-control" value="{{ $equipment_purchase->quantity }}" placeholder="enter quantity" required name="quantity" id="quantity" aria-describedby="emailHelp">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="total_price" class="required">Total Price</label>
                                    <input type="text" class="form-control" value="{{ $equipment_purchase->total_price }}" placeholder="enter total price" required name="total_price" id="total_price" aria-describedby="emailHelp">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="purchase_date" class="required">Purchase Date</label>
                                    <input type="date" class="form-control" value="{{ $equipment_purchase->purchase_date->format('Y-m-d') }}" required name="purchase_date" id="purchase_date" aria-describedby="emailHelp">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="provider">Provider</label>
                                    <input type="text" class="form-control" value="{{ $equipment_purchase->provider }}" placeholder="enter provider name" name="provider" id="provider" aria-describedby="emailHelp">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="transport_cost">Transport Cost</label>
                                    <input type="text" class="form-control" value="{{ $equipment_purchase->transport_cost }}" placeholder="enter transport cost" name="transport_cost" id="transport_cost" aria-describedby="emailHelp">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="labour_cost">Labour Cost</label>
                                    <input type="text" class="form-control" value="{{ $equipment_purchase->labour_cost }}" placeholder="enter labour cost" name="labour_cost" id="labour_cost" aria-describedby="emailHelp">
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary float-right">Save</button>
                            <button type="reset" class="btn btn-danger float-right mr-2">Reset</button>
                        </form>
                    </div>
                </div>
            </div>
            <!-- card single end -->
        </div>
    </div>
@endsection
