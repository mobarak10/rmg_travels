@extends('layouts.app')
@section('title', $title)
@section('content')
    <div class="container">
        <!-- card components -->
        <div class="row">
            <!-- card single -->
            <div class="col-lg-12 mb-3">
                <div class="card">
                    <div class="card-header">
                        Create Menu
                    </div>
                    <div class="card-body">
                        <form action="{{ route('menu.store') }}" method="POST">
                            @csrf
                            <div class="form-group">
                                <label for="exampleInputEmail1" class="required">Menu Name</label>
                                <input type="text" class="form-control" placeholder="enter menu name" required name="name" id="exampleInputEmail1" aria-describedby="emailHelp">
                                <small id="emailHelp" class="form-text text-muted">Menu name should be right side menu option name.</small>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Description</label>
                                <textarea name="description" class="form-control" placeholder="Enter description"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary float-right">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
            <!-- card single end -->
        </div>
    </div>
@endsection
