@extends('layouts.app')

@section('content')
    <!-- Main Content -->
    <div class="container">

        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="m-0">All Labour Cost</h5>

                <div class="btn-group" role="group" aria-label="Action area">
                    <a href="#" onclick="window.print()" title="Print" class="btn btn-secondary btn-sm print-none rounded mr-1"><i aria-hidden="true" class="fa fa-print"></i></a>
                    <!-- for refresh -->
                    <a href="{{ route('labourCost.index') }}" class="btn btn-warning btn-sm rounded print-none mr-1" title="Refresh">
                        <i class="fa fa-refresh" aria-hidden="true"></i>
                    </a>

                    <button class="btn btn-info print-none btn-sm rounded mr-1" type="button" data-toggle="collapse" data-target="#searchEquipment">
                        <i class="fa fa-search"></i>
                    </button>

                    <a href="{{ route('labourCost.create') }}" class="btn btn-primary btn-sm rounded print-none" title="Entry new labour cost.">
                        <i class="fa fa-plus"></i>
                    </a>
                    <p class="text-center d-none d-print-block">Date: {{ date('Y-m-d') }}</p>
                </div>

            </div>

            <div class="card-body p-0">
                <div class="from-row print-none">
                    <div class="collapse align-items-center" id="searchEquipment">
                        <form action="{{ route('labourCost.index') }}" method="GET">
                            <input type="hidden" name="search" value="1">

                            <div class="row ml-1 m-1">
                                <div class="form-group col-md-3">
                                    <label for="date-from">From Date</label>
                                    <input type="date" class="form-control" name="from_date" value="{{ request()->from_date ?? '' }}" id="date-form">
                                </div>

                                <div class="form-group col-md-3">
                                    <label for="date-to">To Date</label>
                                    <input type="date" class="form-control" name="to_date" value="{{ request()->to_date ?? date('Y-m-d') }}" id="date-to">
                                </div>

                                <div class="form-group col-md-3">
                                    <label for="site_id">Site Name</label>
                                    <select name="condition[site_id]" id="site_id" class="form-control">
                                        <option value="">Choose One</option>
                                        @foreach($user_sites as $site)
                                            <option {{ ((request()->condition['site_id'] ?? '') == $site->id) ? 'selected' : '' }} value="{{ $site->id }}">{{ $site->title }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group col-md-3">
                                    <label for="supplier_id">Supplier</label>
                                    <select name="condition[supplier_id]" id="supplier_id" class="form-control">
                                        <option value="">Choose One</option>
                                        @foreach($suppliers as $supplier)
                                            <option {{ ((request()->condition['supplier_id'] ?? '') == $supplier->id) ? 'selected' : '' }} value="{{ $supplier->id }}">
                                                {{ $supplier->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group col-md-12 text-right">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-search"></i>
                                        Search
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <table class="table table-striped table-bordered table-sm">
                    <thead>
                    <tr>
                        <th class="text-center">#</th>
                        <th>Site Name</th>
                        <th>Date</th>
                        <th>Labour Type</th>
                        <th>Supplier</th>
                        <th class="text-right">Total Labour</th>
                        <th class="text-right">Bonus</th>
                        <th class="text-right">Amount</th>
{{--                        <th>Operator</th>--}}
                        <th class="text-right print-none">Action</th>
                    </tr>
                    </thead>

                    <tbody>
                    @forelse($labour_costs as $labour_cost)
                        <tr>
                            <td class="text-center">{{ $loop->index + 1 }}.</td>
                            <td>{{ $labour_cost->sites->title }}</td>
                            <td>{{ $labour_cost->given_date->format('d-M-Y') }}</td>
                            <td>{{ $labour_cost->labour_type }}</td>
                            <td>{{ $labour_cost->suppliers->name }}</td>
                            <td class="text-right">{{ $labour_cost->total_labour }}</td>
                            <td class="text-right">{{ number_format($labour_cost->bonus, 2) ?? 0.00 }}</td>
                            <td class="text-right">{{ number_format($labour_cost->total_amount, 2) }}</td>
{{--                            <td>{{ $labour_cost->users->name }}</td>--}}
                            <td class="text-right">
                                <a href="{{ route('labourCost.show', $labour_cost->id) }}" class="btn btn-sm btn-success print-none" title="Labour cost details.">
                                    <i class="fa fa-eye" aria-hidden="true"></i>
                                </a>

                                <a href="{{ route('labourCost.edit', $labour_cost->id) }}" class="btn btn-sm btn-primary print-none" title="Change labour cost information.">
                                    <i class="fa fa-pencil" aria-hidden="true"></i>
                                </a>

                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="text-center">No labour cost available</td>
                        </tr>
                    @endforelse
                    </tbody>
                </table>
                <!-- paginate -->
                <div class="float-right mx-2">{{ $labour_costs->links() }}</div>
            </div>
        </div>
    </div>
@endsection

