<!-- Topbar -->
<div class="topbar navbar shadow-sm p-0 sticky-top">
    <div class="row mx-0 w-100">
        <!-- Topbar logo -->
        <div class="topbar-brand d-flex align-items-center">

            <!-- Initial logo -->
            <a href="dashboard.html" class="initial-logo">
                <img src="./images/topbar/brand.svg" class="img-fluid" alt=""/>
            </a>
            <!-- Initial logo -->

            <!-- Topbar collapse logo -->
            <a href="dashboard.html" class="collapse-logo">
                <img src="./images/topbar/Twitter_Logo_Blue.svg" class="img-fluid" alt=""/>
            </a>
            <!-- Topbar collapse logo -->
        </div>
        <!-- Topbar end -->

        <!-- Topbar menu -->
        <div class="topbar-menu d-flex align-items-center justify-content-between">

            <!-- Sidebar toggler -->
            <div class="sidebar-toggler d-none d-lg-flex">
                <i class="material-icons md-48">menu</i>
            </div>
            <!-- Sidebar toggler end -->

            <!-- Right menu -->
            <div class="right-menu d-flex align-items-center ml-auto ml-lg-0">

                <!-- Search bar -->
                <div class="input-group search-bar d-none d-lg-block">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search" aria-label="search" aria-describedby="button-addon2">
                        <div class="input-group-append">
                            <button class="btn btn-primary d-flex" type="button" id="button-addon2"><i class="material-icons">search</i></button>
                        </div>
                    </div>
                </div>
                <!-- Search bar end -->

                <!-- search bar phone -->
                <div class="dropdown mobile-search-bar d-lg-none">
                    <div class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
                        <i class="material-icons">search</i>
                    </div>
                    <div class="dropdown-menu dropdown-menu-right py-0 border-0 shadow-sm" aria-labelledby="dropdownMenuButton">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search" aria-label="search" aria-describedby="button-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary d-flex" type="button" id="button-addon2"><i class="material-icons">search</i></button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Search bar phone end -->

                <!-- Messages -->
                <div class="dropdown messages">
                    <div class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
                        <i class="material-icons">email</i>
                    </div>
                    <div class="dropdown-menu dropdown-menu-right shadow-sm" aria-labelledby="dropdownMenuButton">
                        <div class="dropdown-header">
                            <p>User Messages</p>
                            <span>25 Messages</span>
                        </div>
                        <div class="dropdown-body">
                            <a href="#" class="dropdown-item">
                                <img src="./images/topbar/user.png" class="img-fluid" alt=""/>
                                <div class="item-content">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione, doloremque!</p>
                                    <span>2 Days Ago</span>
                                </div>
                            </a>
                            <a href="#" class="dropdown-item">
                                <img src="./images/topbar/user.png" class="img-fluid" alt=""/>
                                <div class="item-content">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione, doloremque!</p>
                                    <span>2 Days Ago</span>
                                </div>
                            </a>
                            <a href="#" class="dropdown-item">
                                <img src="./images/topbar/user.png" class="img-fluid" alt=""/>
                                <div class="item-content">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione, doloremque!</p>
                                    <span>2 Days Ago</span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- Messages end -->

                <!-- Notifications -->
                <div class="dropdown notifications">
                    <div class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
                        <i class="material-icons">notifications</i>
                    </div>
                    <div class="dropdown-menu dropdown-menu-right shadow-sm" aria-labelledby="dropdownMenuButton">
                        <div class="dropdown-header">
                            <p>User Notifications</p>
                            <span>25 Notifications</span>
                        </div>
                        <div class="dropdown-body">
                            <a href="#" class="dropdown-item">
                                <i class="material-icons text-primary">check_circle_outline</i>
                                <div class="item-content">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione, doloremque!</p>
                                    <span>2 Days Ago</span>
                                </div>
                            </a>
                            <a href="#" class="dropdown-item">
                                <i class="material-icons text-danger">error_outline</i>
                                <div class="item-content">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione, doloremque!</p>
                                    <span>2 Days Ago</span>
                                </div>
                            </a>
                            <a href="#" class="dropdown-item">
                                <i class="material-icons text-warning">delete_sweep</i>
                                <div class="item-content">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione, doloremque!</p>
                                    <span>2 Days Ago</span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- Notifications end -->

                <!-- Profile -->
                <div class="dropdown profile">
                    <div class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
                        <img src="./images/topbar/user.png" class="img-fluid" alt=""/>
                    </div>
                    <div class="dropdown-menu dropdown-menu-right shadow-sm" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="#"><i class="material-icons">person</i> Profile</a>
                        <a class="dropdown-item" href="#"><i class="material-icons">message</i> Messages</a>
                        <a class="dropdown-item" href="#"><i class="material-icons">notifications</i> Notifications</a>
                        <a class="dropdown-item" href="#"><i class="material-icons">exit_to_app</i> Logout</a>
                    </div>
                </div>
                <!-- Profile end -->

            </div>
            <!-- Right menu end -->
        </div>
        <!-- Topbar menu end -->
    </div>
</div>
<!-- Topbar end -->
