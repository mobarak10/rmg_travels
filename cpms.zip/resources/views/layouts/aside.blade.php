<!-- Main wrapper -->
<div class="main-wrapper">

    <!-- Sidebar -->
    <div class="navbar-nav sidebar accordion shadow-sm" id="accordionExample">

        <!-- Sidebar heading -->
        <div class="sidebar-heading">
            <h4>Menus</h4>
        </div>

        <!-- Nav item -->
        <div class="nav-item">
            <a class="nav-link" href="dashboard.html">
                <i class="material-icons">dashboard</i>
                <span>Dashboard</span>
            </a>
        </div>
        <!-- Nav item end -->

        <!-- Nav item -->
        <div class="nav-item">
            <a class="nav-link" href="#">
                <i class="material-icons">tag_faces</i>
                <span>Overview</span>
            </a>
        </div>
        <!-- Nav item end -->

        <!-- Nav item -->
        <div class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                <i class="material-icons">bar_chart</i>
                <span>Reports</span>
            </a>
            <div id="collapseOne" class="collapse collapse-body" aria-labelledby="headingOne" data-parent="#accordionExample">
                <h5>Reports</h5>
                <ul>
                    <li>
                        <a href="#">Main Functions</a>
                    </li>
                    <li>
                        <a href="#">All Apis</a>
                    </li>
                    <li>
                        <a href="#">Quick Menu</a>
                    </li>
                    <li>
                        <a href="#">Brodcasting</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Nav item end -->

        <!-- Nav item -->
        <div class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                <i class="material-icons">widgets</i>
                <span>Components</span>
            </a>
            <div id="collapseTwo" class="collapse collapse-body" aria-labelledby="headingOne" data-parent="#accordionExample">
                <h5>Components</h5>
                <ul>
                    <li>
                        <a href="cards.html">Cards</a>
                    </li>
                    <li>
                        <a href="tables.html">Tables</a>
                    </li>
                    <li>
                        <a href="#">Quick Menu</a>
                    </li>
                    <li>
                        <a href="#">Brodcasting</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Nav item end -->

        <!-- Sidebar divider -->
        <div class="sidebar-divider"></div>

        <!-- Sidebar heading -->
        <div class="sidebar-heading">
            <h4>Others</h4>
        </div>

        <!-- Nav item -->
        <div class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
                <i class="material-icons">people</i>
                <span>Users</span>
            </a>
            <div id="collapseThree" class="collapse collapse-body" aria-labelledby="headingOne" data-parent="#accordionExample">
                <h5>Users</h5>
                <ul>
                    <li>
                        <a href="#">Main Functions</a>
                    </li>
                    <li>
                        <a href="#">All Apis</a>
                    </li>
                    <li>
                        <a href="#">Quick Menu</a>
                    </li>
                    <li>
                        <a href="#">Brodcasting</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Nav item end -->

        <!-- Nav item -->
        <div class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
                <i class="material-icons">pie_chart</i>
                <span>Statistics</span>
            </a>
            <div id="collapseFour" class="collapse collapse-body" aria-labelledby="headingOne" data-parent="#accordionExample">
                <h5>Statistics</h5>
                <ul>
                    <li>
                        <a href="#">Main Functions</a>
                    </li>
                    <li>
                        <a href="#">All Apis</a>
                    </li>
                    <li>
                        <a href="#">Quick Menu</a>
                    </li>
                    <li>
                        <a href="#">Brodcasting</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Nav item end -->

        <!-- Nav item -->
        <div class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFive" aria-expanded="true" aria-controls="collapseFive">
                <i class="material-icons">category</i>
                <span>Categories</span>
            </a>
            <div id="collapseFive" class="collapse collapse-body" aria-labelledby="headingOne" data-parent="#accordionExample">
                <h5>Categories</h5>
                <ul>
                    <li>
                        <a href="#">Main Functions</a>
                    </li>
                    <li>
                        <a href="#">All Apis</a>
                    </li>
                    <li>
                        <a href="#">Quick Menu</a>
                    </li>
                    <li>
                        <a href="#">Brodcasting</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Nav item end -->

        <!-- Sidebar divider -->
        <div class="sidebar-divider"></div>

        <!-- Sidebar heading -->
        <div class="sidebar-heading">
            <h4>More</h4>
        </div>

        <!-- Nav item -->
        <div class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSix" aria-expanded="true" aria-controls="collapseSix">
                <i class="material-icons">view_quilt</i>
                <span>Menu</span>
            </a>
            <div id="collapseSix" class="collapse collapse-body" aria-labelledby="headingOne" data-parent="#accordionExample">
                <h5>UX theory</h5>
                <ul>
                    <li>
                        <a href="#">All</a>
                    </li>
                    <li>
                        <a href="#">Create</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Nav item end -->

        <!-- Nav item -->
        <div class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="true" aria-controls="collapseSeven">
                <i class="material-icons">wb_incandescent</i>
                <span>Ui Concepts</span>
            </a>
            <div id="collapseSeven" class="collapse collapse-body" aria-labelledby="headingOne" data-parent="#accordionExample">
                <h5>Ui Concepts</h5>
                <ul>
                    <li>
                        <a href="#">Main Functions</a>
                    </li>
                    <li>
                        <a href="#">All Apis</a>
                    </li>
                    <li>
                        <a href="#">Quick Menu</a>
                    </li>
                    <li>
                        <a href="#">Brodcasting</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Nav item end -->

    </div>
    <!-- Sidebar end -->
</div>
