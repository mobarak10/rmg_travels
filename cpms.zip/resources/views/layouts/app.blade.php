<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Google material design icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
</head>
<body>
<div id="app">
        <!-- Topbar -->
        <div class="topbar navbar shadow-sm p-0 sticky-top">
            <div class="row mx-0 w-100">
                <!-- Topbar logo -->
                <div class="topbar-brand d-flex align-items-center">

                    <!-- Initial logo -->
                    <a href="{{ route('site.index') }}" class="initial-logo">
                        <img src="{{ asset('images/topbar/brand.svg') }}" class="img-fluid" alt=""/>
                    </a>
                    <!-- Initial logo -->

                    <!-- Topbar collapse logo -->
                    <a href="dashboard.html" class="collapse-logo">
                        <img src="{{ asset('images/topbar/Twitter_Logo_Blue.svg') }}" class="img-fluid" alt=""/>
                    </a>
                    <!-- Topbar collapse logo -->
                </div>
                <!-- Topbar end -->

                <!-- Topbar menu -->
                <div class="topbar-menu d-flex align-items-center justify-content-between">

                    <!-- Sidebar toggler -->
                    <div class="sidebar-toggler d-none d-lg-flex">
                        <i class="material-icons md-48">menu</i>
                    </div>
                    <!-- Sidebar toggler end -->

                    <!-- Right menu -->
                    <div class="right-menu d-flex align-items-center ml-auto ml-lg-0">

                        <!-- Profile -->
                        <div class="dropdown profile">
                            <div class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
                                {{--  {{ $admin = Auth::user() }} --}}
{{--                                <img src="{{ (Auth::user()->logo != null) ? Storage::url(Auth::user()->logo) : asset('images/profile/profile.png') }}" class="img-fluid" alt=""/>--}}
                                <img src="{{ asset('images/profile/profile.png') }}" class="img-fluid" alt=""/>
                            </div>
                            <div class="dropdown-menu dropdown-menu-right shadow-sm" aria-labelledby="dropdownMenuButton">
{{--                                <a class="dropdown-item" href="#"><i class="material-icons">person</i> Profile</a>--}}
                                <a class="dropdown-item" href="{{ route('logout') }}"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <i class="material-icons">exit_to_app</i> Logout</a>
                                </a>
                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                    @csrf
                                </form>

                            </div>
                        </div>
                        <!-- Profile end -->

                    </div>
                    <!-- Right menu end -->
                </div>
                <!-- Topbar menu end -->
            </div>
        </div>
        <!-- Topbar end -->

        <!-- Main wrapper -->
        <div class="main-wrapper">
            <!-- Sidebar -->
            <div class="navbar-nav sidebar accordion shadow-sm" id="accordionExample">

                <!-- Sidebar heading -->
                <div class="sidebar-heading">
                    <h4>Menus</h4>
                </div>

                <!-- Nav item -->
                @can('create', App\Models\Site::class)
                    <div class="nav-item">
                        <a class="nav-link" href="{{ route('site.index') }}">
                            <i class="material-icons">dashboard</i>
                            <span>Site Management</span>
                        </a>
                    </div>
                @endcan
            <!-- Nav item end -->

{{--                <!-- Nav item -->--}}
{{--                <div class="nav-item">--}}
{{--                    <a class="nav-link" href="#">--}}
{{--                        <i class="material-icons">tag_faces</i>--}}
{{--                        <span>Equipments</span>--}}
{{--                    </a>--}}
{{--                </div>--}}
{{--                <!-- Nav item end -->--}}

                <!-- Nav item -->
                <div class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseEquipment" aria-expanded="true" aria-controls="collapseEquipment">
                        <i class="material-icons">bar_chart</i>
                        <span>Equipment</span>
                    </a>
                    <div id="collapseEquipment" class="collapse collapse-body {{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'equipmentPurchase.index' OR \Illuminate\Support\Facades\Route::currentRouteName() == 'equipment.create') ? 'show' : '' }}" aria-labelledby="headingEquipment" data-parent="#accordionExample">
                        <h5>Reports</h5>
                        <ul>
                            <li>
                                <a href="{{ route('equipmentPurchase.index') }}" class="{{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'equipmentPurchase.index') ? 'active' : '' }}">All Equipment Purchase</a>
                            </li>
                            <li>
                                <a href="{{ route('equipmentPurchase.create') }}" class="{{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'equipmentPurchase.create') ? 'active' : '' }}">Purchase Equipment</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Nav item end -->

                <!-- Nav item -->
                <div class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapselabour" aria-expanded="true" aria-controls="collapselabour">
                        <i class="material-icons">widgets</i>
                        <span>Labour Cost</span>
                    </a>
                    <div id="collapselabour" class="collapse collapse-body {{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'labourCost.index' OR \Illuminate\Support\Facades\Route::currentRouteName() == 'labourCost.create') ? 'show' : '' }}" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <h5>Components</h5>
                        <ul>
                            <li>
                                <a href="{{ route('labourCost.index') }}" class="{{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'labourCost.index') ? 'active' : '' }}">All Labour Cost</a>
                            </li>
                            <li>
                                <a href="{{ route('labourCost.create') }}" class="{{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'labourCost.create') ? 'active' : '' }}">New Labour Cost</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Nav item end -->

                <!-- Nav item -->
                <div class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseMachineCost" aria-expanded="true" aria-controls="collapseMachineCost">
                        <i class="material-icons">
                            agriculture
                        </i>
                        <span>Machinery Cost</span>
                    </a>
                    <div id="collapseMachineCost" class="collapse collapse-body {{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'machineCost.index' OR \Illuminate\Support\Facades\Route::currentRouteName() == 'machineCost.create') ? 'show' : '' }}" aria-labelledby="headingOne" data-parent="#accordionExample">
{{--                        <h5>Components</h5>--}}
                        <ul>
                            <li>
                                <a href="{{ route('machineCost.index') }}" class="{{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'machineCost.index') ? 'active' : '' }}">All Machinery Cost</a>
                            </li>
                            <li>
                                <a href="{{ route('machineCost.create') }}" class="{{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'machineCost.create') ? 'active' : '' }}">New Machinery Cost</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Nav item end -->

                <!-- Nav item -->
                <div class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTransportCost" aria-expanded="true" aria-controls="collapseTransportCost">
                        <i class="material-icons">
                            local_shipping
                        </i>
                        <span>Transport Cost</span>
                    </a>
                    <div id="collapseTransportCost" class="collapse collapse-body {{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'transportCost.index' OR \Illuminate\Support\Facades\Route::currentRouteName() == 'transportCost.create') ? 'show' : '' }}" aria-labelledby="headingOne" data-parent="#accordionExample">
                        {{--                        <h5>Components</h5>--}}
                        <ul>
                            <li>
                                <a href="{{ route('transportCost.index') }}" class="{{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'transportCost.index') ? 'active' : '' }}">All Transport Cost</a>
                            </li>
                            <li>
                                <a href="{{ route('transportCost.create') }}" class="{{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'transportCost.create') ? 'active' : '' }}">New Transport Cost</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Nav item end -->

{{--                <!-- Sidebar divider -->--}}
{{--                <div class="sidebar-divider"></div>--}}

{{--                <!-- Sidebar heading -->--}}
{{--                <div class="sidebar-heading">--}}
{{--                    <h4>Others</h4>--}}
{{--                </div>--}}

{{--                <!-- Nav item -->--}}
{{--                <div class="nav-item">--}}
{{--                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">--}}
{{--                        <i class="material-icons">people</i>--}}
{{--                        <span>Users</span>--}}
{{--                    </a>--}}
{{--                    <div id="collapseThree" class="collapse collapse-body" aria-labelledby="headingOne" data-parent="#accordionExample">--}}
{{--                        <h5>Users</h5>--}}
{{--                        <ul>--}}
{{--                            <li>--}}
{{--                                <a href="#">Main Functions</a>--}}
{{--                            </li>--}}
{{--                            <li>--}}
{{--                                <a href="#">All Apis</a>--}}
{{--                            </li>--}}
{{--                            <li>--}}
{{--                                <a href="#">Quick Menu</a>--}}
{{--                            </li>--}}
{{--                            <li>--}}
{{--                                <a href="#">Brodcasting</a>--}}
{{--                            </li>--}}
{{--                        </ul>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!-- Nav item end -->--}}

{{--                <!-- Nav item -->--}}
{{--                <div class="nav-item">--}}
{{--                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFour" aria-expanded="true" aria-controls="collapseFour">--}}
{{--                        <i class="material-icons">pie_chart</i>--}}
{{--                        <span>Statistics</span>--}}
{{--                    </a>--}}
{{--                    <div id="collapseFour" class="collapse collapse-body" aria-labelledby="headingOne" data-parent="#accordionExample">--}}
{{--                        <h5>Statistics</h5>--}}
{{--                        <ul>--}}
{{--                            <li>--}}
{{--                                <a href="#">Main Functions</a>--}}
{{--                            </li>--}}
{{--                            <li>--}}
{{--                                <a href="#">All Apis</a>--}}
{{--                            </li>--}}
{{--                            <li>--}}
{{--                                <a href="#">Quick Menu</a>--}}
{{--                            </li>--}}
{{--                            <li>--}}
{{--                                <a href="#">Brodcasting</a>--}}
{{--                            </li>--}}
{{--                        </ul>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!-- Nav item end -->--}}

{{--                <!-- Nav item -->--}}
{{--                <div class="nav-item">--}}
{{--                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFive" aria-expanded="true" aria-controls="collapseFive">--}}
{{--                        <i class="material-icons">category</i>--}}
{{--                        <span>Categories</span>--}}
{{--                    </a>--}}
{{--                    <div id="collapseFive" class="collapse collapse-body" aria-labelledby="headingOne" data-parent="#accordionExample">--}}
{{--                        <h5>Categories</h5>--}}
{{--                        <ul>--}}
{{--                            <li>--}}
{{--                                <a href="#">Main Functions</a>--}}
{{--                            </li>--}}
{{--                            <li>--}}
{{--                                <a href="#">All Apis</a>--}}
{{--                            </li>--}}
{{--                            <li>--}}
{{--                                <a href="#">Quick Menu</a>--}}
{{--                            </li>--}}
{{--                            <li>--}}
{{--                                <a href="#">Brodcasting</a>--}}
{{--                            </li>--}}
{{--                        </ul>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!-- Nav item end -->--}}

                <!-- Sidebar divider -->
                <div class="sidebar-divider"></div>

                <!-- Sidebar heading -->
                <div class="sidebar-heading">
                    <h4>More</h4>
                </div>

                <!-- Nav item -->
                @can('viewAny', App\Models\User::class)
                    <div id="employee" class="nav-item">
                        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseEmployee" aria-expanded="true" aria-controls="collapseEmployee">
                            <i class="material-icons">view_quilt</i>
                            <span>Employee</span>
                        </a>
                        <div id="collapseEmployee" class="collapse collapse-body {{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'employee.index' OR \Illuminate\Support\Facades\Route::currentRouteName() == 'employee.create') ? 'show' : '' }}" aria-labelledby="headingOne" data-parent="#accordionExample">
                            <h5>Menu</h5>
                            <ul>
                                <li>
                                    <a href="{{ route('employee.index') }}" class="{{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'employee.index') ? 'active' : '' }}">All Employee</a>
                                </li>
                                <li>
                                    <a href="{{ route('employee.create') }}" class="{{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'employee.create') ? 'active' : '' }}">Create Employee<Employee></Employee></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                @endcan
                <!-- Nav item end -->

                <!-- Nav item -->
                <div id="supplier" class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSupplier" aria-expanded="true" aria-controls="collapseSupplier">
                        <i class="material-icons">
                        people
                        </i>
                        <span>Supplier</span>
                    </a>
                    <div id="collapseSupplier" class="collapse collapse-body {{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'supplier.index' OR \Illuminate\Support\Facades\Route::currentRouteName() == 'supplier.create') ? 'show' : '' }}" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <h5>Menu</h5>
                        <ul>
                            <li>
                                <a href="{{ route('supplier.index') }}" class="{{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'supplier.index') ? 'active' : '' }}">All Supplier</a>
                            </li>
                            <li>
                                <a href="{{ route('supplier.create') }}" class="{{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'supplier.create') ? 'active' : '' }}">Create Supplier</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Nav item end -->

                <!-- Nav item -->
                <div id="machine" class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseMachine" aria-expanded="true" aria-controls="collapseMachine">
                        <i class="material-icons">
                            moped
                        </i>
                        <span>Machine</span>
                    </a>
                    <div id="collapseMachine" class="collapse collapse-body {{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'machine.index' OR \Illuminate\Support\Facades\Route::currentRouteName() == 'machine.create') ? 'show' : '' }}" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <h5>Menu</h5>
                        <ul>
                            <li>
                                <a href="{{ route('machine.index') }}" class="{{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'machine.index') ? 'active' : '' }}">All Machine</a>
                            </li>
{{--                            <li>--}}
{{--                                <a href="{{ route('machine.create') }}" class="{{ (\Illuminate\Support\Facades\Route::currentRouteName() == 'machine.create') ? 'active' : '' }}">New Machine Entry</a>--}}
{{--                            </li>--}}
                        </ul>
                    </div>
                </div>
                <!-- Nav item end -->

{{--                <!-- Nav item -->--}}
{{--                <div id="menu" class="nav-item active">--}}
{{--                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSix" aria-expanded="true" aria-controls="collapseSix">--}}
{{--                        <i class="material-icons">view_quilt</i>--}}
{{--                        <span>Menu</span>--}}
{{--                    </a>--}}
{{--                    <div id="collapseSix" class="collapse collapse-body show" aria-labelledby="headingOne" data-parent="#accordionExample">--}}
{{--                        <h5>Menu</h5>--}}
{{--                        <ul>--}}
{{--                            <li>--}}
{{--                                <a href="#">All Menu</a>--}}
{{--                            </li>--}}
{{--                            <li>--}}
{{--                                <a class="active" href="{{ route('menu.create') }}">Create Menu</a>--}}
{{--                            </li>--}}
{{--                        </ul>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!-- Nav item end -->--}}

                <!-- Nav item -->
{{--                <div class="nav-item">--}}
{{--                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="true" aria-controls="collapseSeven">--}}
{{--                        <i class="material-icons">--}}
{{--                        no_encryption--}}
{{--                        </i>--}}
{{--                        <span>Permission</span>--}}
{{--                    </a>--}}
{{--                    <div id="collapseSeven" class="collapse collapse-body" aria-labelledby="headingOne" data-parent="#accordionExample">--}}
{{--                        <h5>Permission</h5>--}}
{{--                        <ul>--}}
{{--                            <li>--}}
{{--                                <a href="{{ route('permission.index') }}">All Permission</a>--}}
{{--                            </li>--}}
{{--                            <li>--}}
{{--                                <a href="#">Create Permission</a>--}}
{{--                            </li>--}}
{{--                        </ul>--}}
{{--                    </div>--}}
{{--                </div>--}}
                <!-- Nav item end -->

                <!-- Nav item -->
{{--                <div class="nav-item">--}}
{{--                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseEight" aria-expanded="true" aria-controls="collapseEight">--}}
{{--                        <i class="material-icons">--}}
{{--                        policy--}}
{{--                        </i>--}}
{{--                        <span>Roll</span>--}}
{{--                    </a>--}}
{{--                    <div id="collapseEight" class="collapse collapse-body" aria-labelledby="headingOne" data-parent="#accordionExample">--}}
{{--                        <h5>Roll</h5>--}}
{{--                        <ul>--}}
{{--                            <li>--}}
{{--                                <a href="{{ route('role.index') }}">All Role</a>--}}
{{--                            </li>--}}
{{--                            <li>--}}
{{--                                <a href="#">Create Role</a>--}}
{{--                            </li>--}}
{{--                        </ul>--}}
{{--                    </div>--}}
{{--                </div>--}}
                <!-- Nav item end -->

            </div>
            <!-- Sidebar end -->

            <!-- Content wrapper -->
            <div class="content-wrapper">
                <div class="col-lg-12 mt-2">
                    @include('layouts.alert')
                </div>
                <main>
                    @yield('content')
                </main>
            </div>
            <!-- Content wrapper end -->
        </div>
    </div>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}"></script>
    <script src="{{ asset('js/main.js') }}"></script>
    <script src="{{ asset('vendor/jquery/jquery.js') }}"></script>
@push('script')
        <script>
            $(document).ready(function(){
                $('body').tooltip({
                    selector: '[data-toggle="tooltip"]',
                    container: 'body'
                });
            })
            $document.find('body').append(tooltip);
        </script>
@endpush
</body>
</html>
