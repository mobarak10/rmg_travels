@extends('layouts.app')

@section('content')
    <div class="container">
        <!-- card components -->
        <div class="row mt-3">

            <!-- card single -->
            <div class="col-md-12 mb-3">
                <div class="card">
                    <div class="card-header">
                        DashBoard
                    </div>
                </div>
            </div>
            <!-- card single end -->
        </div>
        <!-- card components end -->
    </div>
@endsection
