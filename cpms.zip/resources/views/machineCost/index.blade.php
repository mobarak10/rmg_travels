@extends('layouts.app')
@section('content')
    <!-- Main Content -->
    <div class="container">

        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="m-0">All Machinery Cost</h5>

                <div class="btn-group" role="group" aria-label="Action area">
                    <a href="#" onclick="window.print();" title="Print" class="btn btn-secondary btn-sm rounded print-none mr-1"><i aria-hidden="true" class="fa fa-print"></i></a>
                    <!-- for refresh -->
                    <a href="{{ route('machineCost.index') }}" class="btn btn-warning rounded print-none mr-1 btn-sm print-none" title="Refresh">
                        <i class="fa fa-refresh" aria-hidden="true"></i>
                    </a>

                    <button class="btn btn-info btn-sm print-none rounded mr-1" type="button" data-toggle="collapse" data-target="#searchEquipment">
                        <i class="fa fa-search"></i>
                    </button>

                    <a href="{{ route('machineCost.create') }}" class="btn btn-primary btn-sm print-none rounded" title="Entry new labour cost.">
                        <i class="fa fa-plus"></i>
                    </a>
                    <p class="text-center d-none d-print-block">Date: {{ date('Y-m-d') }}</p>
                </div>

            </div>

            <div class="card-body p-0">
                <div class="from-row print-none">
                    <div class="collapse align-items-center" id="searchEquipment">
                        <form action="{{ route('machineCost.index') }}" method="GET">
                            <input type="hidden" name="search" value="1">

                            <div class="row ml-1 m-1">
                                <div class="form-group col-md-4">
                                    <label for="date-from">From Date</label>
                                    <input type="date" class="form-control" name="from_date" value="{{ request()->from_date ?? '' }}" id="date-form">
                                </div>

                                <div class="form-group col-md-4">
                                    <label for="date-to">To Date</label>
                                    <input type="date" class="form-control" name="to_date" value="{{ request()->to_date ?? date('Y-m-d') }}" id="date-to">
                                </div>

                                <div class="form-group col-md-4">
                                    <label for="site_id">Site Name</label>
                                    <select name="condition[site_id]" id="site_id" class="form-control">
                                        <option value="">Choose One</option>
                                        @foreach($user_sites as $site)
                                            <option {{ ((request()->condition['site_id'] ?? '') == $site->id) ? 'selected' : '' }} value="{{ $site->id }}">{{ $site->title }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="supplier_id">Supplier</label>
                                    <select name="condition[supplier_id]" id="supplier_id" class="form-control">
                                        <option value="">Choose One</option>
                                        @foreach($suppliers as $supplier)
                                            <option {{ ((request()->condition['supplier_id'] ?? '') == $supplier->id) ? 'selected' : '' }} value="{{ $supplier->id }}">
                                                {{ $supplier->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group col-md-4">
                                    <label for="machine_id">Select Machine</label>
                                    <select name="condition[machine_id]" id="machine_id" class="form-control">
                                        <option value="">Choose One</option>
                                        @foreach($machines as $machine)
                                            <option {{ ((request()->condition['machine_id'] ?? '') == $machine->id) ? 'selected' : '' }} value="{{ $machine->id }}">{{ $machine->name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group col-md-2 text-right" style="margin-top: 30px">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-search"></i>
                                        Search
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <table class="table table-sm table-striped table-bordered">
                    <thead>
                    <tr>
                        <th class="text-center">#</th>
                        <th>Site Name</th>
                        <th>Date</th>
                        <th>Machine Name</th>
                        <th class="text-right">Total Hour</th>
                        <th class="text-right">Total Cost</th>
{{--                        <th>Operator</th>--}}
                        <th class="text-right print-none">Action</th>
                    </tr>
                    </thead>

                    <tbody>
                    @forelse($machine_costs as $machine_cost)
                        <tr>
                            <td class="text-center">{{ $loop->index + 1 }}.</td>
                            <td>{{ $machine_cost->sites->title }}</td>
                            <td>{{ $machine_cost->date->format('d-M-Y') }}</td>
                            <td>{{ $machine_cost->machines->name }}</td>
                            <td class="text-right">{{ $machine_cost->hour_spent }}</td>
                            <td class="text-right">{{ number_format($machine_cost->total_cost, 2) }}</td>
                            <td class="text-right print-none">
                                <a href="{{ route('machineCost.show', $machine_cost->id) }}" class="btn btn-success btn-sm" title="Labour cost details.">
                                    <i class="fa fa-eye" aria-hidden="true"></i>
                                </a>

                                <a href="{{ route('machineCost.edit', $machine_cost->id) }}" class="btn btn-primary btn-sm" title="Change labour cost information.">
                                    <i class="fa fa-pencil" aria-hidden="true"></i>
                                </a>

                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="text-center">No machine cost available</td>
                        </tr>
                    @endforelse
                    </tbody>
                </table>
                <!-- paginate -->
                <div class="float-right mx-2">{{ $machine_costs->links() }}</div>
            </div>
        </div>
    </div>
@endsection

