@extends('layouts.app')

@section('content')
    <div class="container">
        <!-- card components -->
        <div class="row">
            <!-- card single -->
            <div class="col-lg-12 mb-3">
                <div class="card">
                    <div class="card-header">
                        Enter Machine Cost
                    </div>
                    <div class="card-body">
                        <form action="{{ route('machineCost.store') }}" method="POST">
                            @csrf
                            <div class="mb-2">
                                <span style="font-size: small">(NB: All <span style="color: red">*</span> mark must fillable)</span>
                            </div>
                            @if(count($user_sites) > 1)
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="site_id" class="required">Select Site</label>
                                        <select class="form-control" name="site_id" id="site_id">
                                            <option value="">Choose One</option>
                                            @foreach($user_sites as $site)
                                                <option value="{{ $site->id }}">{{ $site->title }}</option>
                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="date" class="required">Given Date</label>
                                        <input type="date" class="form-control" value="{{ date('Y-m-d') }}" required name="date" id="date" aria-describedby="emailHelp">
                                    </div>
                                </div>
                            @else
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="site_id" class="required">Site Name</label>
                                        @foreach($user_sites as $site)
                                            <input type="text" class="form-control" value="{{ $site->title }}" readonly>
                                        @endforeach
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="date" class="required">Given Date</label>
                                        <input type="date" class="form-control" value="{{ date('Y-m-d') }}" required name="date" id="date" aria-describedby="emailHelp">
                                    </div>
                                </div>
                            @endif

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="machine_id" class="required">Machine</label>
                                    <select name="machine_id" id="machine_id" class="form-control">
                                        <option value="" selected disabled>Choose One</option>
                                        @foreach($machines as $machine)
                                            <option value="{{ $machine->id }}">{{ $machine->name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="supplier_id">Machine Provider</label>
                                    <select name="supplier_id" id="supplier_id" class="form-control">
                                        <option value="" selected disabled>Choose One</option>
                                        @foreach($suppliers as $supplier)
                                            <option value="{{ $supplier->id }}">{{ $supplier->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="hourly_rate">Hourly Rate</label>
                                    <input type="text" class="form-control" placeholder="enter hourly rate" value="{{ old('hour_rent') }}" name="hourly_rate" id="hourly_rate" aria-describedby="emailHelp">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="hour_spent">Hour Spent</label>
                                    <input type="text" class="form-control" value="{{ old('hour_spent') }}" placeholder="enter total hour" name="hour_spent" id="hour_spent" aria-describedby="emailHelp">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="driver_cost">Driver Cost</label>
                                    <input type="text" placeholder="enter driver cost" class="form-control" value="{{ old('driver_cost') }}" name="driver_cost" id="driver_cost" aria-describedby="emailHelp">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="total_cost">Total Cost</label>
                                    <input type="text" placeholder="enter total cost" class="form-control" value="{{ old('total_cost') }}" name="total_cost" id="total_cost" aria-describedby="emailHelp">
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary float-right">Save</button>
                            <button type="reset" class="btn btn-danger float-right mr-2">Reset</button>
                        </form>
                    </div>
                </div>
            </div>
            <!-- card single end -->
        </div>
    </div>
@endsection
