@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="m-0">Add Employee</h5>

                    <div class="btn-group" role="group" aria-label="Action area">
                        <a href="{{ route('employee.index') }}" class="btn btn-primary" title="All Employee">
                            <i class="fa fa-list" aria-hidden="true"></i>
                        </a>
                    </div>
                </div>

                <div class="card-body">
                    <form action="{{ route('employee.store') }}" method="post" enctype="multipart/form-data">
                        @csrf
                        <h5>Basic Section</h5>
                        <div class="form-row">
                            <div class="form-group col-md-12 required">
                                <label for="name">Name</label>
                                <input type="text" class="form-control" value="{{ old('name') }}" id="name" name="name" placeholder="Enter employee name" required>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6 required">
                                <label for="phone">Phone Number</label>
                                <input type="text" class="form-control" value="{{ old('phone') }}" id="phone" name="phone" placeholder="Enter employee phone no" required>
                            </div>

                            <div class="form-group col-md-6 required">
                                <label for="email">Email</label>
                                <input type="email" value="{{ old('email') }}" class="form-control" name="email" placeholder="enter email" required>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-12 required">
                                <label for="address">Address</label>
                                <textarea name="address" class="form-control" placeholder="enter present address" id="address" required>{{ old('address') }}</textarea>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <strong class="d-block my-3">Site section<hr></strong>
                            <div class="form-row">
                                <div class="form-group col-md-12 required">
                                    @foreach ($sites as $site)
                                        <div class="form-check">
                                            <input type="checkbox" name="sites[]" value="{{ $site->id }}" id="{{ $site->title }}" class="form-check-input">
                                            <label class="form-check-label" for="{{ $site->title }}">
                                                <span class="d-block">{{ $site->title }}</span>
                                            </label>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>

                        <!-- role section start -->
                        <div class="col-md-6">
                            <strong class="d-block my-3">Role section<hr></strong>

                            <div class="form-row">
                                <div class="form-group">
                                    @foreach ($roles as $role)
                                        <div class="form-check">
                                            <input type="checkbox" name="roles[]" value="{{ $role->id }}" id="{{ $role->slug }}" class="form-check-input">
                                            <label class="form-check-label" for="{{ $role->slug }}">
                                                <span class="d-block">{{ $role->name }}</span>
                                                <small>{{ $role->description }}</small>
                                            </label>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                        <!-- role section end -->

                        <hr>
                        <h5>Password Section</h5>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label>Password</label>
                                <input type="password" class="form-control" name="password" placeholder="enter password">
                            </div>

                            <div class="form-group col-md-6">
                                <label>Confirm Password</label>
                                <input type="password" class="form-control" name="password_confirmation" placeholder="Retype password">
                            </div>
                        </div>

                        <div class="text-right">
                            <button type="reset" class="btn btn-danger">Reset</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- main-panel ends -->
@endsection

