@extends('layouts.app')

@section('content')
<!-- Main Content -->
<div class="container">

	<div class="card">
		<div class="card-header d-flex justify-content-between align-items-center">
			<h5 class="m-0">All Employee</h5>

			<div class="btn-group" role="group" aria-label="Action area">
				<a href="{{ route('employee.create') }}" class="btn btn-primary" title="Create new account.">
					<i class="fa fa-plus"></i>
				</a>
			</div>

		</div>

		<div class="card-body p-0">
			<table class="table">
				<thead>
					<tr>
						<th class="text-center">#</th>
						<th>Name</th>
						<th>Phone</th>
						<th>Email</th>
						<th>Status</th>
						<th class="text-right">Action</th>
					</tr>
				</thead>

				<tbody>
					@foreach($users as $key => $user)
						<tr>
							<td class="text-center">{{ $loop->index + 1 }}.</td>
							<td>{{ $user->name }}</td>
							<td>{{ $user->phone }}</td>
							<td>{{ $user->email }}</td>
							<td>
								{{ $user->status ? 'Active' : 'Inactive' }}
							</td>
							<td class="text-right">
                                <a href="{{ route('employee.changeEmployeeStatus', $user->id) }}" class="btn btn-{{ ($user->status) ? 'warning' : 'success' }}">
                                    <i class="fa fa-{{ ($user->status) ? 'ban' : 'check-circle-o' }}" title="{{ ($user->status) ? "Click for inactive" : 'Click for active' }}"></i>
                                </a>

								<a href="{{ route('employee.edit', $user->id) }}" class="btn btn-primary" title="Change account information.">
									<i class="fa fa-pencil" aria-hidden="true"></i>
								</a>
							</td>
						</tr>
					@endforeach
				</tbody>
			</table>
		</div>
	</div>
</div>
@endsection

