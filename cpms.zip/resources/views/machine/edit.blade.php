@extends('layouts.app')

@section('content')
    <div class="container">
        <!-- card components -->
        <div class="row">
            <!-- card single -->
            <div class="col-lg-12 mb-3">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5>Labour Cost Update</h5>

                        <div class="btn-group" role="group" aria-label="Action area">
                            <a href="{{ route('labourCost.index') }}" class="btn btn-primary" title="Entry new labour cost.">
                                <i class="fa fa-list"></i>
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('labourCost.update', $labour_cost->id) }}" method="POST">
                            @csrf
                            @method('PATCH')
                            <div class="mb-2">
                                <span style="font-size: small">(NB: All <span style="color: red">*</span> mark must fillable)</span>
                            </div>
                            @if(count($user_sites->sites) > 1)
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="site_id" class="required">Select Site</label>
                                        <select class="form-control" name="site_id" id="site_id">
                                            <option value="">Choose One</option>
                                            @foreach($user_sites->sites as $site)
                                                <option value="{{ $site->id }}" {{ ($labour_cost->sites->id == $site->id) ? 'selected' : '' }}>{{ $site->title }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            @endif

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="total_worker">Total Worker</label>
                                    <input type="text" class="form-control" value="{{ $labour_cost->total_worker }}" placeholder="enter total labour number" name="total_worker" id="total_worker" aria-describedby="emailHelp">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="total_amount" class="required">Total Amount</label>
                                    <input type="text" class="form-control" value="{{ $labour_cost->total_amount }}" placeholder="enter total amount" required name="total_amount" id="total_amount" aria-describedby="emailHelp">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-12">
                                    <label for="given_date" class="required">Given Date</label>
                                    <input type="date" class="form-control" value="{{ $labour_cost->given_date->format('Y-m-d') }}" required name="given_date" id="given_date" aria-describedby="emailHelp">
                                </div>

                                {{--                                <div class="form-group col-md-6">--}}
                                {{--                                    <label for="provider" class="required">Provider</label>--}}
                                {{--                                    <input type="text" class="form-control" placeholder="enter provider name" required name="provider" id="provider" aria-describedby="emailHelp">--}}
                                {{--                                </div>--}}
                            </div>

                            <button type="submit" class="btn btn-primary float-right">Save</button>
                            <button type="reset" class="btn btn-danger float-right mr-2">Reset</button>
                        </form>
                    </div>
                </div>
            </div>
            <!-- card single end -->
        </div>
    </div>
@endsection
