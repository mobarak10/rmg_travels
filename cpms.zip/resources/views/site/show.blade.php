@extends('layouts.app')

@section('content')
<!-- Main Content -->
<div class="container-fluid">
	<div class="row">

		<!-- Profile -->
		<div class="col-md-4 mb-3 print-none">
			<div class="card">
				<div class="card-body">
					<h5 class="card-title">{{ $site->title }}</h5>
				</div>

				<ul class="list-group list-group-flush">
					<li class="list-group-item">
						<small class="d-block">Address</small>
						{{ $site->address }}
					</li>

                    @foreach($site->users as $user)
                        <li class="list-group-item">
                            <small class="d-block">Manager</small>
                            {{ $user->name }}
                        </li>
                    @endforeach

                    <li class="list-group-item print-none">
                        <small class="d-block">Start Date</small>
                        {{ $site->start_date->format('d-M-Y') }}
                    </li>

                    <li class="list-group-item print-none">
                        <small class="d-block">End Date</small>
                        {{ $site->end_date->format('d-M-Y') }}
                    </li>

                    <li class="list-group-item print-none">
                        <small class="d-block">Budget</small>
                        {{ number_format($site->budget, 2) }}
                    </li>
				</ul>

				<div class="card-body print-none">
					<a href="{{ route('site.edit', $site->id) }}" class="card-link">Change</a>
				</div>
			</div>
		</div>
		<!-- End of the profile -->

		<!-- Details tab -->
		<div class="col-md-8 print-w-expand">
			<ul class="nav nav-tabs print-none" role="tablist">
				<li class="nav-item">
					<a class="nav-link active" data-toggle="tab" href="#profile-home" role="tab" aria-controls="home" aria-selected="true">Home</a>
				</li>

				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#equipment_purchase" role="tab" aria-controls="equipment_purchase" aria-selected="false">Equipment Cost</a>
				</li>

                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#labour_cost" role="tab" aria-controls="labour_cost" aria-selected="false">Labour Cost</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#machine_rent" role="tab" aria-controls="machine_rent" aria-selected="false">Machinery Cost</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#transport_cost" role="tab" aria-controls="transport_cost" aria-selected="false">Transport Cost</a>
                </li>
			</ul>

			<div class="tab-content">
				<div class="tab-pane fade show active" id="profile-home" role="tabpanel" aria-labelledby="home-tab">
                    <h4 class="text-center d-none d-print-block">{{ $site->title }}</h4>
                    <h4 class="text-center d-none d-print-block">Total Cost Summary</h4>
                    <p class="text-center d-none d-print-block">Date: {{ date('Y-m-d') }}</p>
                    <hr class="d-none d-print-block">
                    <div class="d-flex justify-content-between align-items-center">
                        <p class="mt-2 print-none">Site create at <strong>{{ $site->created_at->format('j F, Y') }}</strong> and last updated at <strong>{{ $site->updated_at->format('j F, Y') }}</strong></p>
                        <a href="#" onclick="window.print();" title="Print" class="btn btn-warning btn-sm print-none"><i aria-hidden="true" class="fa fa-print"></i></a>
                    </div>
                    <div class="row mt-2">
                        <!-- card single -->
                        <div class="col-md-6 mb-3">
                            <div class="card">
                                <div class="card-header text-center">
                                    Equipment Purchase Summary
                                </div>
                                <div class="card-body">
                                    <div class="form-group text-center">
                                        <label for="exampleInputEmail1">Total Equipment Purchase </label>
                                        <h4>{{ number_format($equipments->sum('total_equipment_purchase_amount'), 2) }} BDT</h4>
                                    </div>
{{--                                <button type="submit" class="btn btn-primary float-right">Equipment Purchase</button>--}}
                                </div>
                            </div>
                        </div>
                        <!-- card single end -->

                        <!-- card single -->
                        <div class="col-md-6 mb-3">
                            <div class="card">
                                <div class="card-header text-center">
                                    Labour Cost Summery
                                </div>
                                <div class="card-body">
                                    <div class="form-group text-center">
                                        <label for="exampleInputEmail1">Total Labour Cost </label>
                                        <h4>{{ number_format($labour_costs->sum('total_amount'), 2) }} BDT</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- card single end -->
                    </div>

                    <div class="row mt-2">
                        <!-- card single -->
                        <div class="col-md-6 mb-3">
                            <div class="card">
                                <div class="card-header text-center">
                                    Machinery Cost Summery
                                </div>
                                <div class="card-body">
                                    <div class="form-group text-center">
                                        <label for="exampleInputEmail1">Total Machenery Cost </label>
                                        <h4>{{ number_format($machine_costs->sum('total_cost'), 2) }} BDT</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- card single end -->

                        <!-- card single -->
                        <div class="col-md-6 mb-3">
                            <div class="card">
                                <div class="card-header text-center">
                                    Transport Cost Summery
                                </div>
                                <div class="card-body">
                                    <div class="form-group text-center">
                                        <label for="exampleInputEmail1">Total Transport Cost </label>
                                        <h4>{{ number_format($transport_costs->sum('amount'), 2) }} BDT</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- card single end -->
                    </div>

{{--					<div class="col mt-3">--}}
{{--                        <h4>Total Equipment Purchase: {{ number_format($equipments->sum('total_equipment_purchase_amount'), 2) }}</h4>--}}
{{--                        <h4>Total Labour Cost: {{ number_format($labour_costs->sum('total_amount'), 2) }}</h4>--}}
{{--                        <h4>Total Machine Cost: {{ number_format($machine_costs->sum('total_cost'), 2) }}</h4>--}}
{{--					</div>--}}
				</div>

				<div class="tab-pane fade" id="equipment_purchase" role="tabpanel" aria-labelledby="equipment_purchase">
                    <h4 class="text-center d-none d-print-block">{{ $site->title }}</h4>
                    <h4 class="text-center d-none d-print-block">Equipment Purchase</h4>
                    <p class="text-center d-none d-print-block">Date: {{ date('Y-m-d') }}</p>
                    <hr class="d-none d-print-block">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5>Total {{ count($equipments) }} result found</h5>
                        <a href="#" onclick="window.print();" title="Print" class="btn btn-warning btn-sm print-none"><i aria-hidden="true" class="fa fa-print"></i></a>
                    </div>
                    <table class="table table-sm table-hover smallest-table">
                        <thead>
                        <tr>
                            <th>SL</th>
                            <th>Date</th>
                            <th>Item Name</th>
                            <th>Quantity</th>
                            <th class="text-right">Total Price</th>
                            <th class="text-right">Labour Cost</th>
                            <th class="text-right">Transport Cost</th>
                            <th class="text-right">Grand Total</th>
                        </tr>
                        </thead>

                        <tbody>
                        @php
                            $totalAmount = 0.00;
                        @endphp

                        @forelse($equipments as $equipment)

                            @php
                                $totalAmount += $equipment->transport_cost + $equipment->total_price + $equipment->labour_cost;
                            @endphp
                            <tr>
                                <td>{{ $loop->iteration }}.</td>
                                <td>{{ $equipment->purchase_date->format('d-M-Y')  }}</td>
                                <td>{{ $equipment->item_name }}</td>
                                <td>{{ $equipment->quantity }}</td>
                                <td class="text-right">{{ number_format($equipment->total_price, 2) }}</td>
                                <td class="text-right">{{ number_format($equipment->labour_cost, 2) }}</td>
                                <td class="text-right">{{ number_format($equipment->transport_cost, 2) }}</td>
                                <td class="text-right">{{ number_format($equipment->transport_cost + $equipment->total_price + $equipment->labour_cost, 2) }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="text-center">No Equipment purchase available</td>
                            </tr>
                        @endforelse
                        <tr>
                            <th colspan="7" class="text-right">Total Equipment Purchase</th>
                            <th class="text-right">{{ number_format($totalAmount, 2) }}</th>
                        </tr>
                        </tbody>
                    </table>
{{--                    </div>--}}
				</div>

                <div class="tab-pane fade" id="labour_cost" role="tabpanel" aria-labelledby="labour_cost">
                    <h4 class="text-center d-none d-print-block">{{ $site->title }}</h4>
                    <h4 class="text-center d-none d-print-block">Labour Cost</h4>
                    <p class="text-center d-none d-print-block">Date: {{ date('Y-m-d') }}</p>
                    <hr class="d-none d-print-block">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5>Total {{ count($labour_costs) }} result found</h5>
                        <a href="#" onclick="window.print();" title="Print" class="btn btn-warning btn-sm print-none"><i aria-hidden="true" class="fa fa-print"></i></a>
                    </div>
                    <table class="table table-sm table-hover smallest-table">
                        <thead>
                        <tr>
                            <th>SL</th>
                            <th>Date</th>
                            <th>Supplier Name</th>
                            <th>Labour Type</th>
                            <th>Total Labour</th>
                            <th class="text-right">Grand Total</th>
                        </tr>
                        </thead>

                        <tbody>
                        @php
                            $totalAmount = 0.00;
                        @endphp

                        @forelse($labour_costs as $labour_cost)

                            @php
                                $totalAmount += $labour_cost->total_amount;
                            @endphp
                            <tr>
                                <td>{{ $loop->iteration }}.</td>
                                <td>{{ $labour_cost->given_date->format('d-M-Y')  }}</td>
                                <td>{{ $labour_cost->suppliers->name }}</td>
                                <td>{{ $labour_cost->labour_type }}</td>
                                <td>{{ $labour_cost->total_labour }}</td>
                                <td class="text-right">{{ number_format($labour_cost->total_amount, 2) }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="text-center">No labour cost available</td>
                            </tr>
                        @endforelse
                        <tr>
                            <th colspan="5" class="text-right">Total Labour Cost</th>
                            <th class="text-right">{{ number_format($totalAmount, 2) }}</th>
                        </tr>
                        </tbody>
                    </table>
                </div>

                <div class="tab-pane fade" id="machine_rent" role="tabpanel" aria-labelledby="machine_rent">
                    <h4 class="text-center d-none d-print-block">{{ $site->title }}</h4>
                    <h4 class="text-center d-none d-print-block">Machinery Cost</h4>
                    <p class="text-center d-none d-print-block">Date: {{ date('Y-m-d') }}</p>
                    <hr class="d-none d-print-block">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5>Total {{ count($machine_costs) }} result found</h5>
                        <a href="#" onclick="window.print();" title="Print" class="btn btn-warning btn-sm print-none"><i aria-hidden="true" class="fa fa-print"></i></a>
                    </div>
                    <table class="table table-sm table-hover smallest-table">
                        <thead>
                        <tr>
                            <th>SL</th>
                            <th>Date</th>
                            <th>Supplier Name</th>
                            <th>Hourly Rate</th>
                            <th>Hour Spent</th>
                            <th class="text-right">Driver Cost</th>
                            <th class="text-right">Grand Total</th>
                        </tr>
                        </thead>

                        <tbody>
                        @php
                            $totalAmount = 0.00;
                        @endphp

                        @forelse($machine_costs as $machine_cost)

                            @php
                                $totalAmount += $machine_cost->total_cost;
                            @endphp
                            <tr>
                                <td>{{ $loop->iteration }}.</td>
                                <td>{{ $machine_cost->date->format('d-M-Y')  }}</td>
                                <td>{{ $machine_cost->suppliers->name }}</td>
                                <td>{{ $machine_cost->hourly_rate }}</td>
                                <td>{{ $machine_cost->hour_spent }}</td>
                                <td class="text-right">{{ number_format($machine_cost->driver_cost, 2) }}</td>
                                <td class="text-right">{{ number_format($machine_cost->total_cost, 2) }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="text-center">No machine cost available</td>
                            </tr>
                        @endforelse
                        <tr>
                            <th colspan="6" class="text-right">Total Machine Cost</th>
                            <th class="text-right">{{ number_format($totalAmount, 2) }}</th>
                        </tr>
                        </tbody>
                    </table>
                </div>

                <div class="tab-pane fade" id="transport_cost" role="tabpanel" aria-labelledby="transport_cost">
                    <h4 class="text-center d-none d-print-block">{{ $site->title }}</h4>
                    <h4 class="text-center d-none d-print-block">Transport Cost</h4>
                    <p class="text-center d-none d-print-block">Date: {{ date('Y-m-d') }}</p>
                    <hr class="d-none d-print-block">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5>Total {{ count($transport_costs) }} result found</h5>
                        <a href="#" onclick="window.print();" title="Print" class="btn btn-warning btn-sm print-none"><i aria-hidden="true" class="fa fa-print"></i></a>
                    </div>
                    <table class="table table-sm table-hover">
                        <thead>
                        <tr>
                            <th>SL</th>
                            <th>Date</th>
                            <th>Transport Name</th>
                            <th>Purpose</th>
                            <th class="text-right">Amount</th>
                        </tr>
                        </thead>

                        <tbody>
                        @php
                            $totalAmount = 0.00;
                        @endphp

                        @forelse($transport_costs as $transport_cost)

                            @php
                                $totalAmount += $transport_cost->amount;
                            @endphp
                            <tr>
                                <td>{{ $loop->iteration }}.</td>
                                <td>{{ $transport_cost->date->format('d-M-Y')  }}</td>
                                <td>{{ $transport_cost->transport_name }}</td>
                                <td>{{ $transport_cost->purpose }}</td>
                                <td class="text-right">{{ number_format($transport_cost->amount, 2) }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="text-center">No Transport cost available</td>
                            </tr>
                        @endforelse
                        <tr>
                            <th colspan="4" class="text-right">Total Transport Cost</th>
                            <th class="text-right">{{ number_format($totalAmount, 2) }}</th>
                        </tr>
                        </tbody>
                    </table>
                </div>
			</div>
		</div>
		<!-- Details tab end -->

	</div>
</div>
@endsection

