<?php

namespace App\Http\Controllers;

use App\Models\Machine;
use App\Models\MachineCost;
use App\Models\Site;
use App\Models\Supplier;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class MachineCostController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $suppliers = Supplier::all();
        $machines = Machine::all();
        if (Auth::user()->is_admin != true){
            $user_sites = Site::whereHas('users', function (Builder $query) {
                $query->where('user_id', Auth::user()->id);
            })->get();
        }else{
            $user_sites = Site::active()->get();
        }

        if (Auth::user()->is_admin == true){
            $machine_costs = MachineCost::orderBy('site_id', 'asc')->paginate(15);
        }else{
            $machine_costs = MachineCost::where('user_id', Auth::user()->id)->orderBy('site_id', 'asc')->paginate(15);
        }

        if(request()->search) {
            // return request()->all();
            $from_date = request()->from_date;
            $to_date = request()->to_date;
            // set contition
            $where = [];

            foreach(request()->condition as $key => $value) {
                if($value != null) {
                    if($key == 'item_name') {
                        $where[] = [$key, 'like', '%' . $value . '%'];
                    } else {
                        $where[] = [$key, '=', $value];
                    }
                }
            }

            if (request()->from_date != null){
                // get data
                $machine_costs = MachineCost::where($where)->whereBetween('date', [$from_date, $to_date])->paginate(15);
            }else{
                // get data
                $machine_costs = MachineCost::where($where)->paginate(15);
            }
        }

        return view('machineCost.index', compact('machine_costs', 'suppliers', 'user_sites', 'machines'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $suppliers = Supplier::all();
        $machines = Machine::all();
        $user_sites = Site::whereHas('users', function (Builder $query) {
            $query->where('user_id', Auth::user()->id);
        })->active()->get();

        return view('machineCost.create', compact('user_sites', 'suppliers', 'machines'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'machine_id' => 'required|integer',
            'site_id' => 'required|integer',
            'supplier_id' => 'nullable|integer',
            'date' => 'required|date',
            'hourly_rate' => 'nullable|string',
            'hour_spent' => 'nullable|string',
            'driver_cost' => 'nullable|string',
            'total_cost' => 'required|string'
        ]);

        $data['user_id'] = Auth::user()->id;

        MachineCost::create($data);

        session()->flash('success', 'Machine cost successfully entry!!!.');

        return redirect(route('machineCost.index'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $suppliers = Supplier::all();
        $machines = Machine::all();
        if (Auth::user()->is_admin != true){
            $user_sites = Site::whereHas('users', function (Builder $query) {
                $query->where('user_id', Auth::user()->id);
            })->get();
        }else{
            $user_sites = Site::active()->get();
        }
        $machine_cost = MachineCost::findOrFail($id);

        return view('machineCost.edit', compact('machine_cost', 'suppliers', 'user_sites', 'machines'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = $request->validate([
            'machine_id' => 'required|integer',
            'site_id' => 'required|integer',
            'supplier_id' => 'nullable|integer',
            'date' => 'required|date',
            'hourly_rate' => 'nullable|string',
            'hour_spent' => 'nullable|string',
            'driver_cost' => 'nullable|string',
            'total_cost' => 'required|string'
        ]);

        $data['user_id'] = Auth::user()->id;

        $machine_cost = MachineCost::findOrFail($id);
        $machine_cost->update($data);

        session()->flash('success', 'Machine cost successfully updated!!!.');

        return redirect(route('machineCost.index'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
