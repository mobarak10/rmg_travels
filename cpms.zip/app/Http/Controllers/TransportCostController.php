<?php

namespace App\Http\Controllers;

use App\Models\Site;
use App\Models\Supplier;
use App\Models\TransportCost;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TransportCostController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (Auth::user()->is_admin != true){
            $user_sites = Site::whereHas('users', function (Builder $query) {
                $query->where('user_id', Auth::user()->id);
            })->get();
        }else{
            $user_sites = Site::active()->get();
        }

        if (Auth::user()->is_admin == true){
            $transport_costs = TransportCost::orderBy('site_id', 'asc')->paginate(15);
        }else{
            $transport_costs = TransportCost::where('user_id', Auth::user()->id)->orderBy('site_id', 'asc')->paginate(15);
        }

        return view('transportCost.index', compact('user_sites', 'transport_costs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
//        $suppliers = Supplier::all();
        $user_sites = Site::whereHas('users', function (Builder $query) {
            $query->where('user_id', Auth::user()->id);
        })->active()->get();

        return view('transportCost.create', compact('user_sites'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // return $request->all();
        $data = $request->validate([
            'transport_name' => 'required|string',
            'purpose' => 'nullable|string',
            'amount' => 'required|string',
            'date' => 'required|date',
            'site_id' => 'required|integer'
        ]);

        $data['user_id'] = Auth::user()->id;

        TransportCost::create($data);

        session()->flash('success', 'Transport cost successfully entry.');

        return redirect(route('transportCost.index'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user_sites = Site::whereHas('users', function (Builder $query) {
            $query->where('user_id', Auth::user()->id);
        })->active()->get();
        $transport_cost = TransportCost::findOrFail($id);

        return view('transportCost.edit', compact('user_sites', 'transport_cost'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // return $request->all();
        $data = $request->validate([
            'transport_name' => 'required|string',
            'purpose' => 'nullable|string',
            'amount' => 'required|string',
            'date' => 'required|date',
            'site_id' => 'required|integer'
        ]);

        $data['user_id'] = Auth::user()->id;

        $transport_cost = TransportCost::findOrFail($id);
        $transport_cost->update($data);

        session()->flash('success', 'Transport cost successfully updated.');

        return redirect(route('transportCost.index'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
