<?php

namespace App\Http\Controllers;

use App\Models\Business;
use App\Models\Site;
use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class EmployeeController extends Controller
{
    private $meta = [
        'title' => 'Employee',
        'menu' => 'employee',
        'submenu' => ''
    ];

    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->authorize('viewAny', User::class);
        $users = User::all();
        return view('employee.index', compact('users'))->with($this->meta);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $this->authorize('viewAny', User::class);
        $sites = Site::all();
        $roles = Role::all();
        $userRoles = $roles->pluck('id')->toArray();

        return view('employee.create', compact('sites', 'roles', 'userRoles'))->with($this->meta);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
//        $this->validate($request,[
//            'password' => 'required|string|min:6|confirmed'
//        ], [
//            'password.required' => 'Confirmation password does not match'
//        ]);

        // meta data and validation
        $data = $request->validate([
            'name' => 'required|string',
            'address' => 'required|string',
            'phone' => 'required|string',
            'email' => 'required|email',
        ]);

        if ($request->password){
            $request->validate([
                'password' => 'nullable|confirmed'
            ]);
            $data['password'] = Hash::make($request->password);
        }

        $employee = User::create($data);

//        $employee->name = $request->name;
//        $employee->phone = $request->phone;
//        $employee->email = $request->email;
//        $employee->address = $request->address;
//        $employee->password = Hash::make($request->password);

        if ($employee->save()) {

            // set role relation
            $employee->roles()->attach($request->roles);

            // set site relation
            $employee->sites()->attach($request->sites);

            session()->flash('success', 'Employee added successfully.');

            return redirect(route('employee.index'));
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $this->authorize('viewAny', User::class);
        $user = User::find($id);
        $roles = Role::all();
        $sites = Site::all();
        $userRoles = $user->roles->pluck('id')->toArray();
        $userSites = $user->sites->pluck('id')->toArray();

        return view('employee.edit', compact('user', 'roles', 'userRoles', 'sites', 'userSites'))->with($this->meta);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // get user
        $employee = User::findOrFail($id);

        // update primary data
        if($request->section == 'basic') {
            // validation
            $data = $request->validate([
                'name' => 'required|string|max:255',
                'phone' => 'required|string',
                'email' => 'required|string|email|max:255|unique:users,email,' . $id,
                'address' => 'required|string',
            ]);

            // meta data and validation
//            $metas = $request->validate([
//                'dob' => 'required|string',
//                'present_address' => 'required|string',
//                'permanent_address' => 'required|string',
//                'father_name' => 'required|string',
//                'mother_name' => 'required|string',
//                'nid_number' => 'nullable|string',
//                'contact_person_number' => 'required|string',
//                'basic_salary' => 'required|numeric'
//            ]);

            // change employee data
            $employee->update($data);

            // update meta data
//            foreach ($metas as $key => $value){
//                $employee->metas()->updateOrCreate(['meta_key' => $key], ['meta_value' => $value]);
//            }

            // set role relation
            $employee->roles()->sync($request->roles);

            // set site relation
            $employee->sites()->sync($request->sites);
        }

        // update password data
        if($request->section == 'password') {
            $data = $request->validate([
                'password' => 'required|string|min:6|confirmed',
            ]);

            $data['password'] = bcrypt($request->password);

            // change employee password
            $employee->update($data);
        }

        // flash data
        session()->flash('success', 'Employee account update successfully.');

        // view
        return redirect(route('employee.index'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    // status change
    public function changeEmployeeStatus($id){
        $this->authorize('viewAny', User::class);
        $employee = User::find($id);
        $employee->status = ($employee->status) ? 0 : 1;
        $employee->save();

        return redirect()->back()->withSuccess($employee->name . ' Employee successfully ' .($employee->status == true ? 'Activated' : 'Deactivated'));
    }
}
