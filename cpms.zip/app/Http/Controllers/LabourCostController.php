<?php

namespace App\Http\Controllers;

use App\Models\Supplier;
use Illuminate\Database\Eloquent\Builder;
use App\Models\LabourCost;
use App\Models\Site;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LabourCostController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $suppliers = Supplier::all();
        $user_sites = Site::whereHas('users', function (Builder $query) {
            $query->where('user_id', Auth::user()->id);
        })->get();

        if (Auth::user()->is_admin == true){
            $labour_costs = LabourCost::orderBy('site_id', 'asc')->paginate(15);
        }else{
            $labour_costs = LabourCost::where('user_id', Auth::user()->id)->orderBy('site_id', 'asc')->paginate(15);
        }

        if(request()->search) {
            // return request()->all();
            $from_date = request()->from_date;
            $to_date = request()->to_date;
            // set contition
            $where = [];

            foreach(request()->condition as $key => $value) {
                if($value != null) {
                    if($key == 'item_name') {
                        $where[] = [$key, 'like', '%' . $value . '%'];
                    } else {
                        $where[] = [$key, '=', $value];
                    }
                }
            }

            if (request()->from_date != null){
                // get data
                $labour_costs = LabourCost::where($where)->whereBetween('date', [$from_date, $to_date])->paginate(15);
            }else{
                // get data
                $labour_costs = LabourCost::where($where)->paginate(15);
            }
        }

        return view('labourCost.index', compact('labour_costs', 'suppliers', 'user_sites'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $suppliers = Supplier::all();
        $user_sites = Site::whereHas('users', function (Builder $query) {
            $query->where('user_id', Auth::user()->id);
        })->active()->get();

        return view('labourCost.create', compact('user_sites', 'suppliers'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // return $request->all();
        $data = $request->validate([
           'total_labour' => 'nullable|string',
            'total_amount' => 'required|string',
            'given_date' => 'required|date',
            'site_id' => 'required|integer',
            'bonus' => 'nullable',
            'supplier_id' => 'nullable|integer',
            'labour_type' => 'nullable|string'
        ]);

        if ($request->site_id != null){
            $data['site_id'] = $request->site_id;
        }else{
            $user_sites = Site::whereHas('users', function (Builder $query) {
                $query->where('user_id', Auth::user()->id);
            })->active()->first();

            $data['site_id'] = $user_sites->id;
        }

        $data['user_id'] = Auth::user()->id;

        LabourCost::create($data);

        session()->flash('success', 'Labour cost successfully entry!!!.');

        return redirect(route('labourCost.create'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $suppliers = Supplier::all();
        if (Auth::user()->is_admin != true){
            $user_sites = Site::whereHas('users', function (Builder $query) {
                $query->where('user_id', Auth::user()->id);
            })->get();
        }else{
            $user_sites = Site::active()->get();
        }
        $labour_cost = LabourCost::findOrFail($id);

        return view('labourCost.edit', compact('labour_cost', 'user_sites', 'suppliers'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // return $request->all();
        $data = $request->validate([
            'total_labour' => 'nullable|string',
            'total_amount' => 'required|string',
            'given_date' => 'required|date',
            'site_id' => 'required|integer',
            'bonus' => 'nullable',
            'supplier_id' => 'nullable|integer',
            'labour_type' => 'nullable|string'
        ]);
        $data['user_id'] = Auth::user()->id;

        $labour_cost = LabourCost::findOrFail($id);
        $labour_cost->update($data);

        session()->flash('success', 'Labour cost successfully updated!!!.');

        return redirect(route('labourCost.index'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
