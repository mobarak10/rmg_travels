<?php

namespace App\Http\Controllers;

use App\Models\Business;
use App\Models\Equipment;
use App\Models\EquipmentPurchase;
use App\Models\LabourCost;
use App\Models\MachineCost;
use App\Models\Site;
use App\Models\TransportCost;
use App\Models\User;
use Illuminate\Http\Request;

class SiteController extends Controller
{
    private $meta = [
        'title' => 'Employee',
        'menu' => 'employee',
        'submenu' => ''
    ];

    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->authorize('viewAny', Site::class);
        $sites = Site::all();
        return view('site.index', compact('sites'))->with($this->meta);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $this->authorize('create', Site::class);
        $users = User::active()->get();
        return view('site.create', compact('users'))->with($this->meta);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string',
            'details' => 'nullable|string',
            'address' => 'required|string',
        ]);

        $data = [
            'title' => $request->title,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
            'budget' => $request->budget,
            'address' => $request->address,
            'details' => $request->details
        ];

        $site = Site::create($data);

        $site->users()->attach($request->user_id);

        // flash data
        session()->flash('success', 'Site successfully Created!!.');

        // view
        return redirect(route('site.index'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $this->authorize('viewAny', Site::class);

        $site= Site::find($id);
        $equipments = EquipmentPurchase::where('site_id', $id)->get();
        $labour_costs = LabourCost::where('site_id', $id)->get();
        $machine_costs = MachineCost::where('site_id', $id)->get();
        $transport_costs = TransportCost::where('site_id', $id)->get();
        return view('site.show', compact('site', 'equipments', 'labour_costs', 'machine_costs', 'transport_costs'))->with($this->meta);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $this->authorize('viewAny', Site::class);
        $users = User::active()->get();
        $site = Site::find($id);
        return view('site.edit', compact('site', 'users'))->with($this->meta);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->authorize('edit', Site::class);
        $site = Site::findOrFail($id);

        $data = $request->validate([
            'title' => 'required|string',
            'details' => 'nullable|string',
            'address' => 'required|string',
        ]);


        $site->update($data);

        // flash data
        session()->flash('success', 'Site Updated successfully.');

        // view
        return redirect(route('site.index'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Site::where('id', $id)->delete();
        return redirect()->back();
    }

    public function changeSiteStatus($id)
    {
        $site = Site::find($id);
        $site->status = ($site->status) ? 0 : 1;
        $site->save();

        return redirect()->back()->withSuccess($site->title . ' Site successfully ' .($site->status == true ? 'Activated' : 'Deactivated'));
    }
}
