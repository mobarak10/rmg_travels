<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MachineCost extends Model
{
    use HasFactory;
    protected $fillable = ['site_id', 'user_id', 'date', 'machine_id', 'supplier_id', 'hourly_rate', 'hour_spent', 'driver_cost', 'total_cost'];

    protected $dates = ['date'];

    public function sites()
    {
        return $this->belongsTo('App\Models\Site', 'site_id');
    }

    public function users()
    {
        return $this->belongsTo('App\Models\User', 'user_id');
    }

    public function machines()
    {
        return $this->belongsTo('App\Models\Machine', 'machine_id');
    }

    public function suppliers()
    {
        return $this->belongsTo('App\Models\Supplier', 'supplier_id');
    }
}
