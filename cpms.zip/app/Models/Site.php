<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Site extends Model
{
    protected $fillable = ['title', 'address', 'details', 'start_date', 'end_date', 'budget'];
    use HasFactory;

    protected $dates = ['start_date', 'end_date'];

    /**
     * @return return users site
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function users() {
        return $this->belongsToMany('App\Models\User');
    }

    public function suppliers()
    {
        return $this->belongsTo('App\Models\Supplier');
    }

    /*----------------Scope Start----------------*/
    public function scopeActive($query)
    {
        return $query->where('status', 1);
    }

    public function scopeInactive($query)
    {
        return $query->where('status', 0);
    }
    /*----------------Scope End----------------*/
}
