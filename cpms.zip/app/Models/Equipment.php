<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Equipment extends Model
{
    use HasFactory;
    protected $fillable = [
        'site_id',
        'user_id',
        'item_name',
        'unit_price',
        'quantity',
        'total_price',
        'supplier_id',
        'transport_cost',
        'labour_cost',
        'purchase_date'];
    protected $dates = ['purchase_date'];
    protected $appends = ['total_equipment_purchase_amount'];

    public function sites()
    {
        return $this->belongsTo('App\Models\Site', 'site_id');
    }

    public function users()
    {
        return $this->belongsTo('App\Models\User', 'user_id');
    }

    public function suppliers()
    {
        return $this->belongsTo('App\Models\Supplier', 'supplier_id');
    }

    public function getTotalEquipmentPurchaseAmountAttribute()
    {
        return $this->total_price + $this->transport_cost + $this->labour_cost;
    }
}
