<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TransportCost extends Model
{
    use HasFactory;
    protected $fillable = ['site_id', 'user_id', 'transport_name', 'purpose', 'date', 'amount'];
    protected $dates = ['date'];

    public function sites()
    {
        return $this->belongsTo('App\Models\Site', 'site_id');
    }
}
