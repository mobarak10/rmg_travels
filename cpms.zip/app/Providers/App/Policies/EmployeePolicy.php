<?php


namespace App\Providers\App\Policies;


class EmployeePolicy
{

}
