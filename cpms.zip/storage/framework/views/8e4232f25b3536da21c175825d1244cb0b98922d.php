<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="container">
    <div class="row">
        <div class="col-md-12 pb-3">
            <div class="card">
                <div class="card-header">
					<h5 class="m-0">Update Profile</h5>
                </div>

                <div class="card-body">
                    <div class="row">
                        <!-- basic information section start -->
                        <div class="col-md-12">
                            <form action="<?php echo e(route('employee.update', $user->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>

                                <input type="hidden" name="section" value="basic">

                                <div>
                                    <h5>Basic Section</h5>
                                    <div class="form-row">
                                        <div class="form-group col-md-12 required">
                                            <label for="name">Name</label>
                                            <input type="text" class="form-control" value="<?php echo e((old('name')) ? old('name') : $user->name); ?>" id="name" name="name" placeholder="Enter employee name" required>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-6 required">
                                            <label for="phone">Phone Number</label>
                                            <input type="text" class="form-control" value="<?php echo e((old('phone')) ? old('phone') : $user->phone); ?>" id="phone" name="phone" placeholder="Enter employee phone no" required>
                                        </div>

                                        <div class="form-group col-md-6 required">
                                            <label for="email">Email</label>
                                            <input type="email" value="<?php echo e((old('email')) ? old('email') : $user->email); ?>" class="form-control" name="email" placeholder="enter email" required>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-12 required">
                                            <label for="address">Address</label>
                                            <textarea name="address" class="form-control" placeholder="enter present address" id="address" required><?php echo e((old('address')) ? old('address') : $user->address); ?></textarea>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <strong class="d-block my-3">Site section<hr></strong>
                                        <div class="form-row">
                                            <div class="form-group col-md-12 required">
                                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="form-check">
                                                        <input type="checkbox" name="sites[]" value="<?php echo e($site->id); ?>" id="<?php echo e($site->title); ?>" class="form-check-input" <?php echo e((in_array($site->id, $userSites)) ? 'checked' : ''); ?>>
                                                        <label class="form-check-label" for="<?php echo e($site->title); ?>">
                                                            <span class="d-block"><?php echo e($site->title); ?></span>
                                                        </label>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- role section start -->
                                    <div class="col-md-6">
                                        <strong class="d-block my-3">Role section<hr></strong>

                                        <div class="form-row">
                                            <div class="form-group">
                                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="form-check">
                                                        <input type="checkbox" name="roles[]" value="<?php echo e($role->id); ?>" id="<?php echo e($role->slug); ?>" class="form-check-input" <?php echo e((in_array($role->id, $userRoles)) ? 'checked' : ''); ?>>
                                                        <label class="form-check-label" for="<?php echo e($role->slug); ?>">
                                                            <span class="d-block"><?php echo e($role->name); ?></span>
                                                            <small><?php echo e($role->description); ?></small>
                                                        </label>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- role section end -->

                                    <div class="form-group col-md-12 text-right">
                                        <button type="reset" class="btn btn-danger">Reset</button>
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- basic information section end -->

                        <!-- change password section start -->
                        <div class="col-md-12">
                            <strong class="d-block my-3">Password Section<hr></strong>

                            <form action="<?php echo e(route('employee.update', $user->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>

                                <input type="hidden" name="section" value="password">

                                <div class="form-row">
                                    <div class="form-group col-md-6 required">
                                        <label for="password">Password</label>
                                        <input type="password" name="password" class="form-control" id="password" required>
                                    </div>

                                    <div class="form-group col-md-6 required">
                                        <label for="password_confirmation">Password Confirm</label>
                                        <input type="password" name="password_confirmation" class="form-control" id="password_confirmation" required>
                                    </div>

                                    <div class="form-group col-md-12 text-right">
                                        <button type="reset" class="btn btn-danger">Reset</button>
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- change password section end -->

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\maxsop\cpms\resources\views/employee/edit.blade.php ENDPATH**/ ?>