<?php $__env->startSection('content'); ?>
    <!-- Main Content -->
    <div class="container">

        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="m-0">All Supplier</h5>
                <div class="btn-group" role="group" aria-label="Action area">
                    <a href="<?php echo e(route('supplier.create')); ?>" class="btn btn-primary btn-sm rounded" title="Create new account.">
                        <i class="fa fa-plus"></i>
                    </a>
                </div>
            </div>

            <div class="card-body p-0">
                <table class="table table-bordered table-striped table-sm">
                    <thead>
                    <tr>
                        <th class="text-center">#</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Division</th>
                        <th>District</th>
                        <th class="text-right">Balance</th>
                        <th class="text-right">Action</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($loop->index + 1); ?>.</td>
                            <td><?php echo e($supplier->name); ?></td>
                            <td><?php echo e($supplier->phone); ?></td>
                            <td><?php echo e($supplier->division); ?></td>
                            <td><?php echo e($supplier->district); ?></td>
                            <td class="text-right"><?php echo e(number_format($supplier->balance, 2)); ?></td>
                            <td class="text-right">




                                <a href="<?php echo e(route('supplier.edit', $supplier->id)); ?>" class="btn btn-primary btn-sm" title="Change account information.">
                                    <i class="fa fa-pencil" aria-hidden="true"></i>
                                </a>


                                <a href="<?php echo e(route('supplier.index')); ?>" class="btn btn-danger btn-sm" title="Trash" onClick="if(confirm('Are you sure, You want to delete this?')){event.preventDefault();document.getElementById('delete-form-<?php echo e($supplier->id); ?>').submit();} else {event.preventDefault();}">
                                    <i class="fa fa-times" aria-hidden="true"></i>
                                </a>

                                <form action="<?php echo e(route('supplier.destroy', $supplier->id)); ?>" method="post" id="delete-form-<?php echo e($supplier->id); ?>" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                </form>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\maxsop\cpms\resources\views/supplier/index.blade.php ENDPATH**/ ?>