<?php $__env->startSection('content'); ?>
    <!-- Main Content -->
    <div class="container">

        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="m-0">All Transport Cost</h5>

                <div class="btn-group" role="group" aria-label="Action area">
                    <a href="" onclick="window.print()" title="Print" class="btn btn-secondary btn-sm print-none rounded mr-1"><i aria-hidden="true" class="fa fa-print"></i></a>
                    <!-- for refresh -->
                    <a href="<?php echo e(route('transportCost.index')); ?>" class="btn btn-warning btn-sm print-none rounded mr-1" title="Refresh">
                        <i class="fa fa-refresh" aria-hidden="true"></i>
                    </a>

                    <button class="btn btn-info mr-1 btn-sm print-none rounded" type="button" data-toggle="collapse" data-target="#searchTransportCost">
                        <i class="fa fa-search"></i>
                    </button>

                    <a href="<?php echo e(route('transportCost.create')); ?>" class="btn btn-primary btn-sm rounded print-none" title="Entry new transport cost.">
                        <i class="fa fa-plus"></i>
                    </a>
                    <p class="text-center d-none d-print-block">Date: <?php echo e(date('Y-m-d')); ?></p>
                </div>

            </div>

            <div class="card-body p-0">
                <div class="from-row print-none">
                    <div class="collapse align-items-center" id="searchTransportCost">
                        <form action="<?php echo e(route('transportCost.index')); ?>" method="GET">
                            <input type="hidden" name="search" value="1">

                            <div class="row ml-1 m-1">
                                <div class="form-group col-md-3">
                                    <label for="date-from">From Date</label>
                                    <input type="date" class="form-control" name="from_date" value="<?php echo e(request()->from_date ?? ''); ?>" id="date-form">
                                </div>

                                <div class="form-group col-md-3">
                                    <label for="date-to">To Date</label>
                                    <input type="date" class="form-control" name="to_date" value="<?php echo e(request()->to_date ?? date('Y-m-d')); ?>" id="date-to">
                                </div>

                                <div class="form-group col-md-4">
                                    <label for="site_id">Site Name</label>
                                    <select name="condition[site_id]" id="site_id" class="form-control">
                                        <option value="">Choose One</option>
                                        <?php $__currentLoopData = $user_sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(((request()->condition['site_id'] ?? '') == $site->id) ? 'selected' : ''); ?> value="<?php echo e($site->id); ?>"><?php echo e($site->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group col-md-2 text-right" style="margin-top: 30px">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-search"></i>
                                        Search
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <table class="table table-sm table-striped table-bordered">
                    <thead>
                    <tr>
                        <th class="text-center">#</th>
                        <th>Site Name</th>
                        <th>Date</th>
                        <th>Transport Name</th>
                        <th class="text-right">Amount</th>

                        <th class="text-right print-none">Action</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transport_costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transport_cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-center"><?php echo e($loop->index + 1); ?>.</td>
                            <td><?php echo e($transport_cost->sites->title); ?></td>
                            <td><?php echo e($transport_cost->date->format('d-M-Y')); ?></td>
                            <td><?php echo e($transport_cost->transport_name); ?></td>
                            <td class="text-right"><?php echo e(number_format($transport_cost->amount, 2)); ?></td>
                            <td class="text-right print-none">




                                <a href="<?php echo e(route('transportCost.edit', $transport_cost->id)); ?>" class="btn btn-primary btn-sm" title="Change labour cost information.">
                                    <i class="fa fa-pencil" aria-hidden="true"></i>
                                </a>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center">No Equipment purchase available</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                <!-- paginate -->
                <div class="float-right mx-2"><?php echo e($transport_costs->links()); ?></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\maxsop\cpms\resources\views/transportCost/index.blade.php ENDPATH**/ ?>