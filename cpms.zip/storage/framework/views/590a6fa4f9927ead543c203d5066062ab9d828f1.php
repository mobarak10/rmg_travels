<?php $__env->startSection('content'); ?>
    <div class="container">
        <!-- card components -->
        <div class="row">
            <!-- card single -->
            <div class="col-lg-12 mb-3">
                <div class="card">
                    <div class="card-header">
                        New Equipment Purchase
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('equipmentPurchase.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-2">
                                <span style="font-size: small">(NB: All <span style="color: red">*</span> mark must fillable)</span>
                            </div>
                                <div class="form-row">
                                    <?php if(count($user_sites) > 1): ?>
                                        <div class="form-group col-md-6">
                                            <label for="site_id" class="required">Select Site</label>
                                            <select class="form-control" name="site_id" id="site_id">
                                                <option value="">Choose One</option>
                                                <?php $__currentLoopData = $user_sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($site->id); ?>"><?php echo e($site->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    <?php else: ?>
                                        <div class="form-group col-md-6">
                                            <label for="site_id" class="required">Site Name</label>
                                            <?php $__currentLoopData = $user_sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <input type="text" class="form-control" value="<?php echo e($site->title); ?>" readonly>
                                                <input type="hidden" name="site_id" class="form-control" value="<?php echo e($site->id); ?>">
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                    <div class="form-group col-md-6">
                                        <label for="purchase_date" class="required">Purchase Date</label>
                                        <input type="date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" required name="purchase_date" id="purchase_date" aria-describedby="emailHelp">
                                    </div>
                                </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="supplier_id">Select Supplier</label>
                                    <select name="supplier_id" class="form-control" id="supplier_id">
                                        <option value="">Choose One</option>
                                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="item_name" class="required">Equipment Name</label>
                                    <input type="text" class="form-control" placeholder="Enter equipment name" required name="item_name" id="item_name" aria-describedby="emailHelp">
                                </div>

                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="unit_price">Unit Price</label>
                                    <input type="number" class="form-control" placeholder="Enter unit price" name="unit_price" id="unit_price" aria-describedby="emailHelp">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="quantity" class="required">Quantity</label>
                                    <input type="text" class="form-control" placeholder="Enter quantity" required name="quantity" id="quantity" aria-describedby="emailHelp">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="transport_cost">Transport Cost</label>
                                    <input type="number" class="form-control" placeholder="Enter transport cost" name="transport_cost" id="transport_cost" aria-describedby="emailHelp">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="labour_cost">Labour Cost</label>
                                    <input type="number" class="form-control" placeholder="Enter labour cost" name="labour_cost" id="labour_cost" aria-describedby="emailHelp">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="total_price" class="required">Total Amount</label>
                                    <input type="number" class="form-control" placeholder="Enter total price" required name="total_price" id="total_price" aria-describedby="emailHelp">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="paid_amount" class="required">Paid Amount</label>
                                    <input type="number" class="form-control" value="<?php echo e(old('paid_amount')); ?>" placeholder="Enter how much amount are paid" required name="paid_amount" id="paid_amount" aria-describedby="emailHelp">
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary float-right">Save</button>
                            <button type="reset" class="btn btn-danger float-right mr-2">Reset</button>
                        </form>
                    </div>
                </div>
            </div>
            <!-- card single end -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\maxsop\cpms\resources\views/equipment/create.blade.php ENDPATH**/ ?>