<?php $__env->startSection('content'); ?>
    <div class="container">
        <!-- card components -->
        <div class="row">
            <!-- card single -->
            <div class="col-lg-12 mb-3">
                <div class="card">
                    <div class="card-header">
                        New Transport Cost
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('transportCost.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-2">
                                <span style="font-size: small">(NB: All <span style="color: red">*</span> mark must fillable)</span>
                            </div>
                            <?php if(count($user_sites) > 1): ?>
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="site_id" class="required">Select Site</label>
                                        <select class="form-control" name="site_id" id="site_id">
                                            <option value="">Choose One</option>
                                            <?php $__currentLoopData = $user_sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="site_id" class="required">Site Name</label>
                                        <?php $__currentLoopData = $user_sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <input type="text" class="form-control" value="<?php echo e($site->title); ?>" readonly>
                                            <input type="hidden" name="site_id" class="form-control" value="<?php echo e($site->id); ?>">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="transport_name" class="required">Transport Name</label>
                                    <input type="text" class="form-control" value="<?php echo e(old('transport_name')); ?>" required placeholder="enter transport name" name="transport_name" id="transport_name">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="date" class="required">Date</label>
                                    <input type="date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" name="date" id="date">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="purpose">Purpose</label>
                                    <input type="text" class="form-control" placeholder="enter purpose" name="purpose" id="purpose">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="amount" class="required">Amount</label>
                                    <input type="number" class="form-control" placeholder="enter amount" required name="amount" id="amount">
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary float-right">Save</button>
                            <button type="reset" class="btn btn-danger float-right mr-2">Reset</button>
                        </form>
                    </div>
                </div>
            </div>
            <!-- card single end -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\maxsop\cpms\resources\views/transportCost/create.blade.php ENDPATH**/ ?>