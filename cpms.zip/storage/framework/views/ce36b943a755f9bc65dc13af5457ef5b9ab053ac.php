<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Google material design icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
<div id="app">
        <!-- Topbar -->
        <div class="topbar navbar shadow-sm p-0 sticky-top">
            <div class="row mx-0 w-100">
                <!-- Topbar logo -->
                <div class="topbar-brand d-flex align-items-center">

                    <!-- Initial logo -->
                    <a href="<?php echo e(route('site.index')); ?>" class="initial-logo">
                        <img src="<?php echo e(asset('images/topbar/brand.svg')); ?>" class="img-fluid" alt=""/>
                    </a>
                    <!-- Initial logo -->

                    <!-- Topbar collapse logo -->
                    <a href="dashboard.html" class="collapse-logo">
                        <img src="<?php echo e(asset('images/topbar/Twitter_Logo_Blue.svg')); ?>" class="img-fluid" alt=""/>
                    </a>
                    <!-- Topbar collapse logo -->
                </div>
                <!-- Topbar end -->

                <!-- Topbar menu -->
                <div class="topbar-menu d-flex align-items-center justify-content-between">

                    <!-- Sidebar toggler -->
                    <div class="sidebar-toggler d-none d-lg-flex">
                        <i class="material-icons md-48">menu</i>
                    </div>
                    <!-- Sidebar toggler end -->

                    <!-- Right menu -->
                    <div class="right-menu d-flex align-items-center ml-auto ml-lg-0">

                        <!-- Profile -->
                        <div class="dropdown profile">
                            <div class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
                                

                                <img src="<?php echo e(asset('images/profile/profile.png')); ?>" class="img-fluid" alt=""/>
                            </div>
                            <div class="dropdown-menu dropdown-menu-right shadow-sm" aria-labelledby="dropdownMenuButton">

                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <i class="material-icons">exit_to_app</i> Logout</a>
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>

                            </div>
                        </div>
                        <!-- Profile end -->

                    </div>
                    <!-- Right menu end -->
                </div>
                <!-- Topbar menu end -->
            </div>
        </div>
        <!-- Topbar end -->

        <!-- Main wrapper -->
        <div class="main-wrapper">
            <!-- Sidebar -->
            <div class="navbar-nav sidebar accordion shadow-sm" id="accordionExample">

                <!-- Sidebar heading -->
                <div class="sidebar-heading">
                    <h4>Menus</h4>
                </div>

                <!-- Nav item -->
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Site::class)): ?>
                    <div class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('site.index')); ?>">
                            <i class="material-icons">dashboard</i>
                            <span>Site Management</span>
                        </a>
                    </div>
                <?php endif; ?>
            <!-- Nav item end -->










                <!-- Nav item -->
                <div class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseEquipment" aria-expanded="true" aria-controls="collapseEquipment">
                        <i class="material-icons">bar_chart</i>
                        <span>Equipment</span>
                    </a>
                    <div id="collapseEquipment" class="collapse collapse-body <?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'equipmentPurchase.index' OR \Illuminate\Support\Facades\Route::currentRouteName() == 'equipment.create') ? 'show' : ''); ?>" aria-labelledby="headingEquipment" data-parent="#accordionExample">
                        <h5>Reports</h5>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('equipmentPurchase.index')); ?>" class="<?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'equipmentPurchase.index') ? 'active' : ''); ?>">All Equipment Purchase</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('equipmentPurchase.create')); ?>" class="<?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'equipmentPurchase.create') ? 'active' : ''); ?>">Purchase Equipment</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Nav item end -->

                <!-- Nav item -->
                <div class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapselabour" aria-expanded="true" aria-controls="collapselabour">
                        <i class="material-icons">widgets</i>
                        <span>Labour Cost</span>
                    </a>
                    <div id="collapselabour" class="collapse collapse-body <?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'labourCost.index' OR \Illuminate\Support\Facades\Route::currentRouteName() == 'labourCost.create') ? 'show' : ''); ?>" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <h5>Components</h5>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('labourCost.index')); ?>" class="<?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'labourCost.index') ? 'active' : ''); ?>">All Labour Cost</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('labourCost.create')); ?>" class="<?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'labourCost.create') ? 'active' : ''); ?>">New Labour Cost</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Nav item end -->

                <!-- Nav item -->
                <div class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseMachineCost" aria-expanded="true" aria-controls="collapseMachineCost">
                        <i class="material-icons">
                            agriculture
                        </i>
                        <span>Machinery Cost</span>
                    </a>
                    <div id="collapseMachineCost" class="collapse collapse-body <?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'machineCost.index' OR \Illuminate\Support\Facades\Route::currentRouteName() == 'machineCost.create') ? 'show' : ''); ?>" aria-labelledby="headingOne" data-parent="#accordionExample">

                        <ul>
                            <li>
                                <a href="<?php echo e(route('machineCost.index')); ?>" class="<?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'machineCost.index') ? 'active' : ''); ?>">All Machinery Cost</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('machineCost.create')); ?>" class="<?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'machineCost.create') ? 'active' : ''); ?>">New Machinery Cost</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Nav item end -->

                <!-- Nav item -->
                <div class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTransportCost" aria-expanded="true" aria-controls="collapseTransportCost">
                        <i class="material-icons">
                            local_shipping
                        </i>
                        <span>Transport Cost</span>
                    </a>
                    <div id="collapseTransportCost" class="collapse collapse-body <?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'transportCost.index' OR \Illuminate\Support\Facades\Route::currentRouteName() == 'transportCost.create') ? 'show' : ''); ?>" aria-labelledby="headingOne" data-parent="#accordionExample">
                        
                        <ul>
                            <li>
                                <a href="<?php echo e(route('transportCost.index')); ?>" class="<?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'transportCost.index') ? 'active' : ''); ?>">All Transport Cost</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('transportCost.create')); ?>" class="<?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'transportCost.create') ? 'active' : ''); ?>">New Transport Cost</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Nav item end -->























































































                <!-- Sidebar divider -->
                <div class="sidebar-divider"></div>

                <!-- Sidebar heading -->
                <div class="sidebar-heading">
                    <h4>More</h4>
                </div>

                <!-- Nav item -->
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Models\User::class)): ?>
                    <div id="employee" class="nav-item">
                        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseEmployee" aria-expanded="true" aria-controls="collapseEmployee">
                            <i class="material-icons">view_quilt</i>
                            <span>Employee</span>
                        </a>
                        <div id="collapseEmployee" class="collapse collapse-body <?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'employee.index' OR \Illuminate\Support\Facades\Route::currentRouteName() == 'employee.create') ? 'show' : ''); ?>" aria-labelledby="headingOne" data-parent="#accordionExample">
                            <h5>Menu</h5>
                            <ul>
                                <li>
                                    <a href="<?php echo e(route('employee.index')); ?>" class="<?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'employee.index') ? 'active' : ''); ?>">All Employee</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('employee.create')); ?>" class="<?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'employee.create') ? 'active' : ''); ?>">Create Employee<Employee></Employee></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>
                <!-- Nav item end -->

                <!-- Nav item -->
                <div id="supplier" class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSupplier" aria-expanded="true" aria-controls="collapseSupplier">
                        <i class="material-icons">
                        people
                        </i>
                        <span>Supplier</span>
                    </a>
                    <div id="collapseSupplier" class="collapse collapse-body <?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'supplier.index' OR \Illuminate\Support\Facades\Route::currentRouteName() == 'supplier.create') ? 'show' : ''); ?>" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <h5>Menu</h5>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('supplier.index')); ?>" class="<?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'supplier.index') ? 'active' : ''); ?>">All Supplier</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('supplier.create')); ?>" class="<?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'supplier.create') ? 'active' : ''); ?>">Create Supplier</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Nav item end -->

                <!-- Nav item -->
                <div id="machine" class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseMachine" aria-expanded="true" aria-controls="collapseMachine">
                        <i class="material-icons">
                            moped
                        </i>
                        <span>Machine</span>
                    </a>
                    <div id="collapseMachine" class="collapse collapse-body <?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'machine.index' OR \Illuminate\Support\Facades\Route::currentRouteName() == 'machine.create') ? 'show' : ''); ?>" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <h5>Menu</h5>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('machine.index')); ?>" class="<?php echo e((\Illuminate\Support\Facades\Route::currentRouteName() == 'machine.index') ? 'active' : ''); ?>">All Machine</a>
                            </li>



                        </ul>
                    </div>
                </div>
                <!-- Nav item end -->





















                <!-- Nav item -->



















                <!-- Nav item end -->

                <!-- Nav item -->



















                <!-- Nav item end -->

            </div>
            <!-- Sidebar end -->

            <!-- Content wrapper -->
            <div class="content-wrapper">
                <div class="col-lg-12 mt-2">
                    <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <main>
                    <?php echo $__env->yieldContent('content'); ?>
                </main>
            </div>
            <!-- Content wrapper end -->
        </div>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/jquery/jquery.js')); ?>"></script>
<?php $__env->startPush('script'); ?>
        <script>
            $(document).ready(function(){
                $('body').tooltip({
                    selector: '[data-toggle="tooltip"]',
                    container: 'body'
                });
            })
            $document.find('body').append(tooltip);
        </script>
<?php $__env->stopPush(); ?>
</body>
</html>
<?php /**PATH F:\laragon\maxsop\cpms\resources\views/layouts/app.blade.php ENDPATH**/ ?>