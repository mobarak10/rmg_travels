<?php $__env->startSection('content'); ?>
    <!-- Main Content -->
    <div class="container">
        <div class="row mb-2">
            <div class="col-md-2">

            </div>
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center">
                        Equipment Purchase Information
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush align-items-center">
                            <li class="list-group-item"><span class="font-weight-bold">Site Name:</span> <?php echo e($equipment_purchase->sites->title); ?></li>
                            <li class="list-group-item"><span class="font-weight-bold">Purchase By:</span> <?php echo e($equipment_purchase->users->name); ?></li>
                            <li class="list-group-item"><span class="font-weight-bold">Supplier:</span> <?php echo e($equipment_purchase->suppliers->name); ?></li>
                            <li class="list-group-item"><span class="font-weight-bold">Item Name:</span> <?php echo e($equipment_purchase->item_name); ?></li>
                            <li class="list-group-item"><span class="font-weight-bold">Unit Price:</span> <?php echo e(number_format($equipment_purchase->unit_price, 2)); ?></li>
                            <li class="list-group-item"><span class="font-weight-bold">Quantity:</span> <?php echo e($equipment_purchase->quantity); ?></li>
                            <li class="list-group-item"><span class="font-weight-bold">Total Item Price:</span> <?php echo e(number_format($equipment_purchase->total_price, 2)); ?></li>
                            <li class="list-group-item"><span class="font-weight-bold">Labour Cost:</span> <?php echo e(number_format($equipment_purchase->labour_cost, 2)); ?></li>
                            <li class="list-group-item"><span class="font-weight-bold">Transport Cost:</span> <?php echo e(number_format($equipment_purchase->transport_cost, 2)); ?></li>
                            <li class="list-group-item"><span class="font-weight-bold">Total Cost:</span> <?php echo e(number_format($equipment_purchase->transport_cost+$equipment_purchase->labour_cost+$equipment_purchase->total_price, 2)); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-2">

            </div>
        </div>

        <!--Section: Block Content-->
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\maxsop\cpms\resources\views/equipment/show.blade.php ENDPATH**/ ?>