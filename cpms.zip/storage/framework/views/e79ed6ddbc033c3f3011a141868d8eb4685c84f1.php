<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="m-0">Add Employee</h5>

                    <div class="btn-group" role="group" aria-label="Action area">
                        <a href="<?php echo e(route('employee.index')); ?>" class="btn btn-primary" title="All Employee">
                            <i class="fa fa-list" aria-hidden="true"></i>
                        </a>
                    </div>
                </div>

                <div class="card-body">
                    <form action="<?php echo e(route('employee.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <h5>Basic Section</h5>
                        <div class="form-row">
                            <div class="form-group col-md-12 required">
                                <label for="name">Name</label>
                                <input type="text" class="form-control" value="<?php echo e(old('name')); ?>" id="name" name="name" placeholder="Enter employee name" required>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6 required">
                                <label for="phone">Phone Number</label>
                                <input type="text" class="form-control" value="<?php echo e(old('phone')); ?>" id="phone" name="phone" placeholder="Enter employee phone no" required>
                            </div>

                            <div class="form-group col-md-6 required">
                                <label for="email">Email</label>
                                <input type="email" value="<?php echo e(old('email')); ?>" class="form-control" name="email" placeholder="enter email" required>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-12 required">
                                <label for="address">Address</label>
                                <textarea name="address" class="form-control" placeholder="enter present address" id="address" required><?php echo e(old('address')); ?></textarea>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <strong class="d-block my-3">Site section<hr></strong>
                            <div class="form-row">
                                <div class="form-group col-md-12 required">
                                    <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-check">
                                            <input type="checkbox" name="sites[]" value="<?php echo e($site->id); ?>" id="<?php echo e($site->title); ?>" class="form-check-input">
                                            <label class="form-check-label" for="<?php echo e($site->title); ?>">
                                                <span class="d-block"><?php echo e($site->title); ?></span>
                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>

                        <!-- role section start -->
                        <div class="col-md-6">
                            <strong class="d-block my-3">Role section<hr></strong>

                            <div class="form-row">
                                <div class="form-group">
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-check">
                                            <input type="checkbox" name="roles[]" value="<?php echo e($role->id); ?>" id="<?php echo e($role->slug); ?>" class="form-check-input">
                                            <label class="form-check-label" for="<?php echo e($role->slug); ?>">
                                                <span class="d-block"><?php echo e($role->name); ?></span>
                                                <small><?php echo e($role->description); ?></small>
                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <!-- role section end -->

                        <hr>
                        <h5>Password Section</h5>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label>Password</label>
                                <input type="password" class="form-control" name="password" placeholder="enter password">
                            </div>

                            <div class="form-group col-md-6">
                                <label>Confirm Password</label>
                                <input type="password" class="form-control" name="password_confirmation" placeholder="Retype password">
                            </div>
                        </div>

                        <div class="text-right">
                            <button type="reset" class="btn btn-danger">Reset</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- main-panel ends -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\maxsop\cpms\resources\views/employee/create.blade.php ENDPATH**/ ?>