<?php $__env->startSection('content'); ?>
    <div class="container">
        <!-- card components -->
        <div class="row mt-3">

            <!-- card single -->
            <div class="col-md-12 mb-3">
                <div class="card">
                    <div class="card-header">
                        DashBoard
                    </div>
                </div>
            </div>
            <!-- card single end -->
        </div>
        <!-- card components end -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\maxsop\cpms\resources\views/dashboard.blade.php ENDPATH**/ ?>