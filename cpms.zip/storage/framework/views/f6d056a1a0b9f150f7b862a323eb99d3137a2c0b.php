<?php $__env->startSection('content'); ?>
    <div class="container">
        <!-- card components -->
        <div class="row">
            <!-- card single -->
            <div class="col-lg-12 mb-3">
                <div class="card">
                    <div class="card-header">
                        Enter Machine Cost
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('machineCost.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-2">
                                <span style="font-size: small">(NB: All <span style="color: red">*</span> mark must fillable)</span>
                            </div>
                            <?php if(count($user_sites) > 1): ?>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="site_id" class="required">Select Site</label>
                                        <select class="form-control" name="site_id" id="site_id">
                                            <option value="">Choose One</option>
                                            <?php $__currentLoopData = $user_sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="date" class="required">Given Date</label>
                                        <input type="date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" required name="date" id="date" aria-describedby="emailHelp">
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="site_id" class="required">Site Name</label>
                                        <?php $__currentLoopData = $user_sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <input type="text" class="form-control" value="<?php echo e($site->title); ?>" readonly>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="date" class="required">Given Date</label>
                                        <input type="date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" required name="date" id="date" aria-describedby="emailHelp">
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="machine_id" class="required">Machine</label>
                                    <select name="machine_id" id="machine_id" class="form-control">
                                        <option value="" selected disabled>Choose One</option>
                                        <?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($machine->id); ?>"><?php echo e($machine->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="supplier_id">Machine Provider</label>
                                    <select name="supplier_id" id="supplier_id" class="form-control">
                                        <option value="" selected disabled>Choose One</option>
                                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="hourly_rate">Hourly Rate</label>
                                    <input type="text" class="form-control" placeholder="enter hourly rate" value="<?php echo e(old('hour_rent')); ?>" name="hourly_rate" id="hourly_rate" aria-describedby="emailHelp">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="hour_spent">Hour Spent</label>
                                    <input type="text" class="form-control" value="<?php echo e(old('hour_spent')); ?>" placeholder="enter total hour" name="hour_spent" id="hour_spent" aria-describedby="emailHelp">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="driver_cost">Driver Cost</label>
                                    <input type="text" placeholder="enter driver cost" class="form-control" value="<?php echo e(old('driver_cost')); ?>" name="driver_cost" id="driver_cost" aria-describedby="emailHelp">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="total_cost">Total Cost</label>
                                    <input type="text" placeholder="enter total cost" class="form-control" value="<?php echo e(old('total_cost')); ?>" name="total_cost" id="total_cost" aria-describedby="emailHelp">
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary float-right">Save</button>
                            <button type="reset" class="btn btn-danger float-right mr-2">Reset</button>
                        </form>
                    </div>
                </div>
            </div>
            <!-- card single end -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\maxsop\cpms\resources\views/machineCost/create.blade.php ENDPATH**/ ?>