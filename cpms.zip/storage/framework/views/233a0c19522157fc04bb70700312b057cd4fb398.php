<?php $__env->startSection('content'); ?>
    <div class="container">
        <!-- card components -->
        <div class="row">
            <!-- card single -->
            <div class="col-lg-12 mb-3">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5>Labour Cost Entry</h5>

                        <div class="btn-group" role="group" aria-label="Action area">
                            <a href="<?php echo e(route('labourCost.index')); ?>" class="btn btn-primary" title="Entry new labour cost.">
                                <i class="fa fa-list"></i>
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('labourCost.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-2">
                                <span style="font-size: small">(NB: All <span style="color: red">*</span> mark must fillable)</span>
                            </div>
                            <?php if(count($user_sites) > 1): ?>
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="site_id" class="required">Select Site</label>
                                        <select class="form-control" name="site_id" id="site_id">
                                            <option value="">Choose One</option>
                                            <?php $__currentLoopData = $user_sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="site_id" class="required">Site Name</label>
                                        <?php $__currentLoopData = $user_sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <input type="text" class="form-control" value="<?php echo e($site->title); ?>" readonly>
                                            <input type="hidden" name="site_id" class="form-control" value="<?php echo e($site->id); ?>">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="total_labour">Total Labour</label>
                                    <input type="text" class="form-control" value="<?php echo e(old('total_labour')); ?>" placeholder="enter total labour number" name="total_labour" id="total_labour" aria-describedby="emailHelp">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="given_date" class="required">Given Date</label>
                                    <input type="date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" required name="given_date" id="given_date" aria-describedby="emailHelp">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="labour_type">Labour Type</label>
                                    <input type="text" class="form-control" placeholder="enter labour type" name="labour_type" id="labour_type" aria-describedby="emailHelp">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="supplier_id">Labour Supplier</label>
                                    <select name="supplier_id" id="supplier_id" class="form-control selectpicker">
                                        <option value="">Choose One</option>
                                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="bonus">Bonus</label>
                                    <input type="number" class="form-control" placeholder="enter total amount" name="bonus" id="bonus" aria-describedby="emailHelp">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="total_amount" class="required">Total Amount</label>
                                    <input type="text" class="form-control" placeholder="enter total amount" required name="total_amount" id="total_amount" aria-describedby="emailHelp">
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary float-right">Save</button>
                            <button type="reset" class="btn btn-danger float-right mr-2">Reset</button>
                        </form>
                    </div>
                </div>
            </div>
            <!-- card single end -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\maxsop\cpms\resources\views/labourCost/create.blade.php ENDPATH**/ ?>