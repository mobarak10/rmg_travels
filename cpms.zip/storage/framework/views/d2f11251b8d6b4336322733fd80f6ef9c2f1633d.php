<?php $__env->startSection('content'); ?>
    <!-- Main Content -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="m-0">All Machine</h5>

                        <div class="btn-group" role="group" aria-level="Action area">
                            <button type="button" class="btn btn-primary btn-sm rounded" data-toggle="modal" data-target="#newMachineModal" title="Create new Bank">
                                <i class="fa fa-plus"></i>
                            </button>
                        </div>
                    </div>

                    <div class="card-body p-0">
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th>SL</th>
                                <th>Machine Name</th>
                                <th class="text-right">Action</th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->index + 1); ?>.</td>
                                    <td><?php echo e($machine->name); ?></td>
                                    <td class="text-right">
                                        <a href="<?php echo e(route('machine.show', $machine->id)); ?>" target="_blank" class="btn btn-info">
                                            <i class="fa fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- insert modal start -->
                <div class="modal fade" id="newMachineModal" tabindex="-1" role="dialog" aria-labelledby="insertModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <form action="<?php echo e(route('machine.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>

                                <div class="modal-header">
                                    <h5 class="modal-title" id="insertModalLabel">Enter new machine</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    <div class="form-group required">
                                        <label for="name" class="required">Machine name</label>
                                        <input type="text" id="name" class="form-control" value="<?php echo e(old('name')); ?>" name="name" placeholder="Enter machine name" required>
                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- insert modal end -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\maxsop\cpms\resources\views/machine/index.blade.php ENDPATH**/ ?>