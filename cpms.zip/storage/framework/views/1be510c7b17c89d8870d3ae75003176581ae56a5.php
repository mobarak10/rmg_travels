<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 py-3">

            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="m-0">Create New Supplier</h5>
                    <div class="btn-group" role="group" aria-label="Action area">
                        <a href="<?php echo e(route('supplier.index')); ?>" class="btn btn-primary" title="All supplier">
                            <i class="fa fa-list" aria-hidden="true"></i>
                        </a>
                    </div>
                </div>

                <div class="card-body p-0">
                    <div class="col-12 py-2">
                        <form action="<?php echo e(route('supplier.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="mb-2">
                                <span style="font-size: small">(NB: All <span style="color: red">*</span> mark must fillable)</span>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-12">
                                    <label for="name" class="required">Name</label>
                                    <input type="text" name="name" class="form-control" id="name" required placeholder="Name">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="phone" class="required">Phone</label>
                                    <input type="text" name="phone" class="form-control" required id="phone" placeholder="Phone">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="balance">Balance</label>
                                    <input type="number" name="balance" class="form-control" id="balance" placeholder="Enter supplier balance">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="division">Division</label>
                                    <input class="form-control" name="division" id="division" placeholder="Enter division" />
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="district">District</label>
                                    <input class="form-control" name="district" id="district" placeholder="Enter district" />
                                </div>
                            </div>












                            <div class="text-right">
                                <button type="reset" class="btn btn-danger">Reset</button>
                                <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\maxsop\cpms\resources\views/supplier/create.blade.php ENDPATH**/ ?>