<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="container">

	<div class="card">
		<div class="card-header d-flex justify-content-between align-items-center">
			<h5 class="m-0">All Employee</h5>

			<div class="btn-group" role="group" aria-label="Action area">
				<a href="<?php echo e(route('employee.create')); ?>" class="btn btn-primary" title="Create new account.">
					<i class="fa fa-plus"></i>
				</a>
			</div>

		</div>

		<div class="card-body p-0">
			<table class="table">
				<thead>
					<tr>
						<th class="text-center">#</th>
						<th>Name</th>
						<th>Phone</th>
						<th>Email</th>
						<th>Status</th>
						<th class="text-right">Action</th>
					</tr>
				</thead>

				<tbody>
					<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td class="text-center"><?php echo e($loop->index + 1); ?>.</td>
							<td><?php echo e($user->name); ?></td>
							<td><?php echo e($user->phone); ?></td>
							<td><?php echo e($user->email); ?></td>
							<td>
								<?php echo e($user->status ? 'Active' : 'Inactive'); ?>

							</td>
							<td class="text-right">
                                <a href="<?php echo e(route('employee.changeEmployeeStatus', $user->id)); ?>" class="btn btn-<?php echo e(($user->status) ? 'warning' : 'success'); ?>">
                                    <i class="fa fa-<?php echo e(($user->status) ? 'ban' : 'check-circle-o'); ?>" title="<?php echo e(($user->status) ? "Click for inactive" : 'Click for active'); ?>"></i>
                                </a>

								<a href="<?php echo e(route('employee.edit', $user->id)); ?>" class="btn btn-primary" title="Change account information.">
									<i class="fa fa-pencil" aria-hidden="true"></i>
								</a>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\maxsop\cpms\resources\views/employee/index.blade.php ENDPATH**/ ?>