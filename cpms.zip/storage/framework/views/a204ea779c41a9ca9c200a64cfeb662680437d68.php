<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 mt-3">
            </div>
        </div>

        <div class="row pb-5">
            <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <div class="card-header"><?php echo e($site->title); ?></div>

                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($site->address); ?></h5>
                            <p class="card-text">Last Updated at <?php echo e($site->updated_at->format('j F, Y')); ?></p>

                            <a href="<?php echo e(route('site.show', $site->id)); ?>" class="btn btn-success text-white" title="Site details.">
                                <i class="fa fa-eye" aria-hidden="true"></i>
                            </a>

                            <a href="<?php echo e(route('site.edit', $site->id)); ?>" class="btn btn-success" title="Change Site information.">
                                <i class="fa fa-pencil" aria-hidden="true"></i>
                            </a>

                            <a href="<?php echo e(route('site.index')); ?>" class="btn btn-danger float-right" title="Trash" onClick="if(confirm('Are you sure, You want to delete this record?')){event.preventDefault();document.getElementById('delete-form-<?php echo e($site->id); ?>').submit();} else {event.preventDefault();}">
                                <i class="fa fa-trash" aria-hidden="true"></i>
                            </a>

                            <form action="<?php echo e(route('site.destroy', $site->id)); ?>" method="post" id="delete-form-<?php echo e($site->id); ?>" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                            </form>

                            <a href="<?php echo e(route('site.changeSiteStatus', $site->id)); ?>" class="btn btn-<?php echo e(($site->status) ? 'warning' : 'success'); ?> float-right mr-1">
                                <i class="fa fa-<?php echo e(($site->status) ? 'ban' : 'check-circle-o'); ?>" title="<?php echo e(($site->status) ? "Complete Site" : ''); ?>"></i>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-4">
                <a href="<?php echo e(route('site.create')); ?>" class="btn btn-block btn-primary d-flex flex-column justify-content-center" title="Add new business information." style="height:12.5rem;">
                    <i class="fa fa-plus h2 mb-0" aria-hidden="true"></i>
                    <span class="d-block">Create New Site</span>
                </a>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\maxsop\cpms\resources\views/site/index.blade.php ENDPATH**/ ?>