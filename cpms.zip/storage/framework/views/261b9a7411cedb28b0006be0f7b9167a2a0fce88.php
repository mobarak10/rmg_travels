<?php $__env->startSection('content'); ?>






































































<!-- Sign in -->
<div class="sign-in-wrapper">
    <div class="sign-in shadow-sm">
        <div class="row mx-0 h-100">
            <div class="col-lg-6 px-0 h-100 d-none d-lg-block">
                <div class="left">
                    <img src="<?php echo e(asset('images/topbar/brand.svg')); ?>" class="img-fluid logo" alt=""/>
                    <div class="content">
                        <h2>Welcome to MaxSOP admin</h2>
                        <p>It is a long established fact that a reader will be distracted by the readable content of It is a long established fact that a reader will be distracted by the readable content of It is a long distracted by the readable content of It is a long</p>
                    </div>
                    <div class="social-wrapper">
                        <a  href="#"><i class="icofont-facebook"></i></a>
                        <a  href="#"><i class="icofont-twitter"></i></a>
                        <a  href="#"><i class="icofont-behance"></i></a>
                        <a  href="#"><i class="icofont-linkedin"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 px-0 h-100">
                <div class="right">
                    <h3 class="title">Sign In</h3>
                    <form action="<?php echo e(route('login')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">

                            <div class="col-md-12">
                                <input id="email" placeholder="enter your email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-12">
                                <input id="password" placeholder="enter your password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between align-items-center my-20p">
                            <div class="custom-control custom-checkbox my-1 mr-sm-2">
                                <input type="checkbox" class="custom-control-input" id="customControlInline">
                                <label class="custom-control-label" for="customControlInline">Remember me on this device</label>
                            </div>
                            <?php if(Route::has('password.request')): ?>
                                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                    <?php echo e(__('Forgot Your Password?')); ?>

                                </a>
                            <?php endif; ?>
                        </div>
                        <div class="action-buttons">
                            <button type="submit" class="btn">Sign In</button>
                        </div>



                    </form>
                    <p class="legal">It is a long established fact that a reader will be <a href="#">distracted</a> by the readable content of a page when looking at its layout. The <a href="#">point</a> of using Lorem</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Sign in end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\maxsop\cpms\resources\views/auth/login.blade.php ENDPATH**/ ?>