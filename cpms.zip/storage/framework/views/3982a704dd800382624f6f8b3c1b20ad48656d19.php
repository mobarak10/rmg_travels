<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="container-fluid">
	<div class="row">

		<!-- Profile -->
		<div class="col-md-4 mb-3 print-none">
			<div class="card">
				<div class="card-body">
					<h5 class="card-title"><?php echo e($site->title); ?></h5>
				</div>

				<ul class="list-group list-group-flush">
					<li class="list-group-item">
						<small class="d-block">Address</small>
						<?php echo e($site->address); ?>

					</li>

                    <?php $__currentLoopData = $site->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <small class="d-block">Manager</small>
                            <?php echo e($user->name); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <li class="list-group-item print-none">
                        <small class="d-block">Start Date</small>
                        <?php echo e($site->start_date->format('d-M-Y')); ?>

                    </li>

                    <li class="list-group-item print-none">
                        <small class="d-block">End Date</small>
                        <?php echo e($site->end_date->format('d-M-Y')); ?>

                    </li>

                    <li class="list-group-item print-none">
                        <small class="d-block">Budget</small>
                        <?php echo e(number_format($site->budget, 2)); ?>

                    </li>
				</ul>

				<div class="card-body print-none">
					<a href="<?php echo e(route('site.edit', $site->id)); ?>" class="card-link">Change</a>
				</div>
			</div>
		</div>
		<!-- End of the profile -->

		<!-- Details tab -->
		<div class="col-md-8 print-w-expand">
			<ul class="nav nav-tabs print-none" role="tablist">
				<li class="nav-item">
					<a class="nav-link active" data-toggle="tab" href="#profile-home" role="tab" aria-controls="home" aria-selected="true">Home</a>
				</li>

				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#equipment_purchase" role="tab" aria-controls="equipment_purchase" aria-selected="false">Equipment Cost</a>
				</li>

                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#labour_cost" role="tab" aria-controls="labour_cost" aria-selected="false">Labour Cost</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#machine_rent" role="tab" aria-controls="machine_rent" aria-selected="false">Machinery Cost</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#transport_cost" role="tab" aria-controls="transport_cost" aria-selected="false">Transport Cost</a>
                </li>
			</ul>

			<div class="tab-content">
				<div class="tab-pane fade show active" id="profile-home" role="tabpanel" aria-labelledby="home-tab">
                    <h4 class="text-center d-none d-print-block"><?php echo e($site->title); ?></h4>
                    <h4 class="text-center d-none d-print-block">Total Cost Summary</h4>
                    <p class="text-center d-none d-print-block">Date: <?php echo e(date('Y-m-d')); ?></p>
                    <hr class="d-none d-print-block">
                    <div class="d-flex justify-content-between align-items-center">
                        <p class="mt-2 print-none">Site create at <strong><?php echo e($site->created_at->format('j F, Y')); ?></strong> and last updated at <strong><?php echo e($site->updated_at->format('j F, Y')); ?></strong></p>
                        <a href="#" onclick="window.print();" title="Print" class="btn btn-warning btn-sm print-none"><i aria-hidden="true" class="fa fa-print"></i></a>
                    </div>
                    <div class="row mt-2">
                        <!-- card single -->
                        <div class="col-md-6 mb-3">
                            <div class="card">
                                <div class="card-header text-center">
                                    Equipment Purchase Summary
                                </div>
                                <div class="card-body">
                                    <div class="form-group text-center">
                                        <label for="exampleInputEmail1">Total Equipment Purchase </label>
                                        <h4><?php echo e(number_format($equipments->sum('total_equipment_purchase_amount'), 2)); ?> BDT</h4>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- card single end -->

                        <!-- card single -->
                        <div class="col-md-6 mb-3">
                            <div class="card">
                                <div class="card-header text-center">
                                    Labour Cost Summery
                                </div>
                                <div class="card-body">
                                    <div class="form-group text-center">
                                        <label for="exampleInputEmail1">Total Labour Cost </label>
                                        <h4><?php echo e(number_format($labour_costs->sum('total_amount'), 2)); ?> BDT</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- card single end -->
                    </div>

                    <div class="row mt-2">
                        <!-- card single -->
                        <div class="col-md-6 mb-3">
                            <div class="card">
                                <div class="card-header text-center">
                                    Machinery Cost Summery
                                </div>
                                <div class="card-body">
                                    <div class="form-group text-center">
                                        <label for="exampleInputEmail1">Total Machenery Cost </label>
                                        <h4><?php echo e(number_format($machine_costs->sum('total_cost'), 2)); ?> BDT</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- card single end -->

                        <!-- card single -->
                        <div class="col-md-6 mb-3">
                            <div class="card">
                                <div class="card-header text-center">
                                    Transport Cost Summery
                                </div>
                                <div class="card-body">
                                    <div class="form-group text-center">
                                        <label for="exampleInputEmail1">Total Transport Cost </label>
                                        <h4><?php echo e(number_format($transport_costs->sum('amount'), 2)); ?> BDT</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- card single end -->
                    </div>






				</div>

				<div class="tab-pane fade" id="equipment_purchase" role="tabpanel" aria-labelledby="equipment_purchase">
                    <h4 class="text-center d-none d-print-block"><?php echo e($site->title); ?></h4>
                    <h4 class="text-center d-none d-print-block">Equipment Purchase</h4>
                    <p class="text-center d-none d-print-block">Date: <?php echo e(date('Y-m-d')); ?></p>
                    <hr class="d-none d-print-block">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5>Total <?php echo e(count($equipments)); ?> result found</h5>
                        <a href="#" onclick="window.print();" title="Print" class="btn btn-warning btn-sm print-none"><i aria-hidden="true" class="fa fa-print"></i></a>
                    </div>
                    <table class="table table-sm table-hover smallest-table">
                        <thead>
                        <tr>
                            <th>SL</th>
                            <th>Date</th>
                            <th>Item Name</th>
                            <th>Quantity</th>
                            <th class="text-right">Total Price</th>
                            <th class="text-right">Labour Cost</th>
                            <th class="text-right">Transport Cost</th>
                            <th class="text-right">Grand Total</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php
                            $totalAmount = 0.00;
                        ?>

                        <?php $__empty_1 = true; $__currentLoopData = $equipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <?php
                                $totalAmount += $equipment->transport_cost + $equipment->total_price + $equipment->labour_cost;
                            ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?>.</td>
                                <td><?php echo e($equipment->purchase_date->format('d-M-Y')); ?></td>
                                <td><?php echo e($equipment->item_name); ?></td>
                                <td><?php echo e($equipment->quantity); ?></td>
                                <td class="text-right"><?php echo e(number_format($equipment->total_price, 2)); ?></td>
                                <td class="text-right"><?php echo e(number_format($equipment->labour_cost, 2)); ?></td>
                                <td class="text-right"><?php echo e(number_format($equipment->transport_cost, 2)); ?></td>
                                <td class="text-right"><?php echo e(number_format($equipment->transport_cost + $equipment->total_price + $equipment->labour_cost, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center">No Equipment purchase available</td>
                            </tr>
                        <?php endif; ?>
                        <tr>
                            <th colspan="7" class="text-right">Total Equipment Purchase</th>
                            <th class="text-right"><?php echo e(number_format($totalAmount, 2)); ?></th>
                        </tr>
                        </tbody>
                    </table>

				</div>

                <div class="tab-pane fade" id="labour_cost" role="tabpanel" aria-labelledby="labour_cost">
                    <h4 class="text-center d-none d-print-block"><?php echo e($site->title); ?></h4>
                    <h4 class="text-center d-none d-print-block">Labour Cost</h4>
                    <p class="text-center d-none d-print-block">Date: <?php echo e(date('Y-m-d')); ?></p>
                    <hr class="d-none d-print-block">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5>Total <?php echo e(count($labour_costs)); ?> result found</h5>
                        <a href="#" onclick="window.print();" title="Print" class="btn btn-warning btn-sm print-none"><i aria-hidden="true" class="fa fa-print"></i></a>
                    </div>
                    <table class="table table-sm table-hover smallest-table">
                        <thead>
                        <tr>
                            <th>SL</th>
                            <th>Date</th>
                            <th>Supplier Name</th>
                            <th>Labour Type</th>
                            <th>Total Labour</th>
                            <th class="text-right">Grand Total</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php
                            $totalAmount = 0.00;
                        ?>

                        <?php $__empty_1 = true; $__currentLoopData = $labour_costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $labour_cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <?php
                                $totalAmount += $labour_cost->total_amount;
                            ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?>.</td>
                                <td><?php echo e($labour_cost->given_date->format('d-M-Y')); ?></td>
                                <td><?php echo e($labour_cost->suppliers->name); ?></td>
                                <td><?php echo e($labour_cost->labour_type); ?></td>
                                <td><?php echo e($labour_cost->total_labour); ?></td>
                                <td class="text-right"><?php echo e(number_format($labour_cost->total_amount, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center">No labour cost available</td>
                            </tr>
                        <?php endif; ?>
                        <tr>
                            <th colspan="5" class="text-right">Total Labour Cost</th>
                            <th class="text-right"><?php echo e(number_format($totalAmount, 2)); ?></th>
                        </tr>
                        </tbody>
                    </table>
                </div>

                <div class="tab-pane fade" id="machine_rent" role="tabpanel" aria-labelledby="machine_rent">
                    <h4 class="text-center d-none d-print-block"><?php echo e($site->title); ?></h4>
                    <h4 class="text-center d-none d-print-block">Machinery Cost</h4>
                    <p class="text-center d-none d-print-block">Date: <?php echo e(date('Y-m-d')); ?></p>
                    <hr class="d-none d-print-block">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5>Total <?php echo e(count($machine_costs)); ?> result found</h5>
                        <a href="#" onclick="window.print();" title="Print" class="btn btn-warning btn-sm print-none"><i aria-hidden="true" class="fa fa-print"></i></a>
                    </div>
                    <table class="table table-sm table-hover smallest-table">
                        <thead>
                        <tr>
                            <th>SL</th>
                            <th>Date</th>
                            <th>Supplier Name</th>
                            <th>Hourly Rate</th>
                            <th>Hour Spent</th>
                            <th class="text-right">Driver Cost</th>
                            <th class="text-right">Grand Total</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php
                            $totalAmount = 0.00;
                        ?>

                        <?php $__empty_1 = true; $__currentLoopData = $machine_costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine_cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <?php
                                $totalAmount += $machine_cost->total_cost;
                            ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?>.</td>
                                <td><?php echo e($machine_cost->date->format('d-M-Y')); ?></td>
                                <td><?php echo e($machine_cost->suppliers->name); ?></td>
                                <td><?php echo e($machine_cost->hourly_rate); ?></td>
                                <td><?php echo e($machine_cost->hour_spent); ?></td>
                                <td class="text-right"><?php echo e(number_format($machine_cost->driver_cost, 2)); ?></td>
                                <td class="text-right"><?php echo e(number_format($machine_cost->total_cost, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center">No machine cost available</td>
                            </tr>
                        <?php endif; ?>
                        <tr>
                            <th colspan="6" class="text-right">Total Machine Cost</th>
                            <th class="text-right"><?php echo e(number_format($totalAmount, 2)); ?></th>
                        </tr>
                        </tbody>
                    </table>
                </div>

                <div class="tab-pane fade" id="transport_cost" role="tabpanel" aria-labelledby="transport_cost">
                    <h4 class="text-center d-none d-print-block"><?php echo e($site->title); ?></h4>
                    <h4 class="text-center d-none d-print-block">Transport Cost</h4>
                    <p class="text-center d-none d-print-block">Date: <?php echo e(date('Y-m-d')); ?></p>
                    <hr class="d-none d-print-block">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5>Total <?php echo e(count($transport_costs)); ?> result found</h5>
                        <a href="#" onclick="window.print();" title="Print" class="btn btn-warning btn-sm print-none"><i aria-hidden="true" class="fa fa-print"></i></a>
                    </div>
                    <table class="table table-sm table-hover">
                        <thead>
                        <tr>
                            <th>SL</th>
                            <th>Date</th>
                            <th>Transport Name</th>
                            <th>Purpose</th>
                            <th class="text-right">Amount</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php
                            $totalAmount = 0.00;
                        ?>

                        <?php $__empty_1 = true; $__currentLoopData = $transport_costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transport_cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <?php
                                $totalAmount += $transport_cost->amount;
                            ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?>.</td>
                                <td><?php echo e($transport_cost->date->format('d-M-Y')); ?></td>
                                <td><?php echo e($transport_cost->transport_name); ?></td>
                                <td><?php echo e($transport_cost->purpose); ?></td>
                                <td class="text-right"><?php echo e(number_format($transport_cost->amount, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center">No Transport cost available</td>
                            </tr>
                        <?php endif; ?>
                        <tr>
                            <th colspan="4" class="text-right">Total Transport Cost</th>
                            <th class="text-right"><?php echo e(number_format($totalAmount, 2)); ?></th>
                        </tr>
                        </tbody>
                    </table>
                </div>
			</div>
		</div>
		<!-- Details tab end -->

	</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\maxsop\cpms\resources\views/site/show.blade.php ENDPATH**/ ?>