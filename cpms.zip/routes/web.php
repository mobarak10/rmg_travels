<?php

use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\EquipmentController;
use App\Http\Controllers\EquipmentPurchaseController;
use App\Http\Controllers\LabourCostController;
use App\Http\Controllers\MachineController;
use App\Http\Controllers\MachineCostController;
use App\Http\Controllers\SiteController;
use App\Http\Controllers\SupplierController;
use App\Http\Controllers\TransportCostController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\HomeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Auth::routes(['register' => false]);
Route::get('/', [HomeController::class, 'index'])->name('dashboard');

Auth::routes();

Route::get('/dashboard', [HomeController::class, 'index'])->name('dashboard');
//Route::resource('/menu', MenuController::class);
//Route::resource('/permission', PermissionController::class);
//Route::resource('/role', RoleController::class);
//Route::resource('/employee', EmployeeController::class);
//Route::resource('/site', SiteController::class);
//Route::resource('/equipment', EquipmentController::class);
//Route::resource('/labourCost', LabourCostController::class);
//Route::resource('/supplier', SupplierController::class);

Route::resources([
    '/menu' => MenuController::class,
    '/labourCost' => LabourCostController::class,
    '/equipmentPurchase' => EquipmentPurchaseController::class,
    '/permission' => PermissionController::class,
    '/role' => RoleController::class,
    '/employee' => EmployeeController::class,
    '/site' => SiteController::class,
    '/supplier' => SupplierController::class,
    '/machine' => MachineController::class,
    '/machineCost' => MachineCostController::class,
    '/transportCost' => TransportCostController::class
 ]);


// change Employee status
Route::get('employee/{id}/status', [EmployeeController::class , 'changeEmployeeStatus'])->name('employee.changeEmployeeStatus');

// change site status
Route::get('site/{id}/status', [SiteController::class , 'changeSiteStatus'])->name('site.changeSiteStatus');
